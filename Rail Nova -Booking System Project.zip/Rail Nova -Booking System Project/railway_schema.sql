-- ============================================================
--  Indian Railways Dataset — SQLite Schema
--  For use with Railway Ticket Booking System project
--  Source: datameet/railways (github.com/datameet/railways)
--  Stations: 8990 | Trains: 5208
-- ============================================================

-- STATIONS TABLE
CREATE TABLE IF NOT EXISTS stations (
    station_code TEXT PRIMARY KEY,  -- e.g. 'CSTM', 'NDLS', 'BCT'
    station_name TEXT NOT NULL,
    zone         TEXT,              -- NR, WR, CR, SR, ER, etc.
    state        TEXT,
    address      TEXT,
    longitude    REAL,
    latitude     REAL
);

-- TRAINS TABLE
CREATE TABLE IF NOT EXISTS trains (
    train_number      TEXT PRIMARY KEY,
    train_name        TEXT NOT NULL,
    from_station_code TEXT REFERENCES stations(station_code),
    from_station_name TEXT,
    to_station_code   TEXT REFERENCES stations(station_code),
    to_station_name   TEXT,
    departure         TEXT,         -- HH:MM:SS
    arrival           TEXT,         -- HH:MM:SS
    duration_h        INTEGER,
    duration_m        INTEGER,
    distance_km       REAL,
    train_type        TEXT,         -- Exp, SF, Raj, Mail, DEMU, MEMU, Pass, Drnt, etc.
    zone              TEXT,
    return_train      TEXT,
    has_1ac           INTEGER DEFAULT 0,
    has_2ac           INTEGER DEFAULT 0,
    has_3ac           INTEGER DEFAULT 0,
    has_sleeper       INTEGER DEFAULT 0,
    has_chair_car     INTEGER DEFAULT 0,
    has_first_class   INTEGER DEFAULT 0
);

-- USEFUL QUERIES FOR TICKET BOOKING:

-- 1. Search trains between two stations
-- SELECT * FROM trains WHERE from_station_code='CSTM' AND to_station_code='NDLS';

-- 2. All trains from a city
-- SELECT * FROM trains WHERE from_station_code IN (
--     SELECT station_code FROM stations WHERE station_name LIKE '%MUMBAI%'
-- );

-- 3. Trains with sleeper class
-- SELECT train_number, train_name, from_station_name, to_station_name
-- FROM trains WHERE has_sleeper=1 AND from_station_code='BCT';

-- 4. Rajdhani / Shatabdi / Duronto only
-- SELECT * FROM trains WHERE train_type IN ('Raj','SF','Drnt');

-- 5. Find station code by name
-- SELECT station_code, station_name, state FROM stations WHERE station_name LIKE '%PUNE%';
