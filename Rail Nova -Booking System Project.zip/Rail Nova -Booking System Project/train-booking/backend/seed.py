import os
import csv
import sys
from datetime import datetime, date, timedelta
from sqlalchemy.orm import Session

# Add current directory to path so we can import app
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.database import engine, Base, SessionLocal
from app.models.station import Station
from app.models.train import Train
from app.models.seat import Seat
from app.models.train_stoppage import TrainStoppage

def find_csv_file(filename):
    """Dynamically search for the CSV files in expected folders."""
    possible_paths = [
        os.path.join(os.path.dirname(__file__), "..", "data", filename),
        os.path.join(os.path.dirname(__file__), "..", "..", filename),
        os.path.join(os.path.dirname(__file__), filename),
        os.path.join("data", filename),
        filename
    ]
    for path in possible_paths:
        if os.path.exists(path):
            print(f"Found {filename} at: {os.path.abspath(path)}")
            return path
    raise FileNotFoundError(f"Could not find {filename} in any of the search paths.")

def clean_float(value):
    try:
        return float(value) if value else None
    except ValueError:
        return None

def clean_int(value):
    try:
        return int(float(value)) if value else 0
    except ValueError:
        return 0

def clean_bool(value):
    if not value:
        return False
    # Handles '1', 'true', 'yes'
    return value.strip().lower() in ('1', 'true', 'yes')

def seed_stoppages(db: Session):
    # Check if already seeded
    count = db.query(TrainStoppage).count()
    if count > 0:
        print(f"Stoppages already seeded ({count} records). Skipping.")
        return
        
    print("Seeding train stoppages (this might take a few seconds)...")
    try:
        stoppages_path = find_csv_file("stoppages.csv")
    except FileNotFoundError as e:
        print(f"Skipping stoppages seeding: {e}")
        return
    
    # Load valid station codes and train numbers to avoid foreign key failures
    valid_stations = {s[0] for s in db.query(Station.station_code).all()}
    valid_trains = {t[0] for t in db.query(Train.train_number).all()}
    
    stoppages_to_insert = []
    
    with open(stoppages_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_num = row["train_number"].strip()
            s_code = row["station_code"].strip().upper()
            
            # Skip if either foreign key won't match
            if t_num not in valid_trains or s_code not in valid_stations:
                continue
                
            # clean arrival/departure
            arrival = row.get("arrival", "").strip() or None
            departure = row.get("departure", "").strip() or None
            
            # create stoppage mapping
            stoppage = {
                "train_number": t_num,
                "station_code": s_code,
                "station_name": row["station_name"].strip(),
                "arrival": arrival,
                "departure": departure,
                "day": clean_int(row.get("day", 1)),
                "stop_number": clean_int(row.get("stop_number", 0))
            }
            stoppages_to_insert.append(stoppage)
            
    if stoppages_to_insert:
        print(f"Read {len(stoppages_to_insert)} valid stoppages. Inserting into database in batches...")
        batch_size = 10000
        for i in range(0, len(stoppages_to_insert), batch_size):
            batch = stoppages_to_insert[i:i+batch_size]
            db.bulk_insert_mappings(TrainStoppage, batch)
            db.commit()
        print(f"Seeded {len(stoppages_to_insert)} stoppages successfully.")
    else:
        print("No stoppages to seed.")

def seed_database():
    print("Dropping all existing SQLite tables to remove old data...")
    Base.metadata.drop_all(bind=engine)
    print("Initializing SQLite tables...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # 1. Seed Stations
        print("Seeding stations...")
        station_path = find_csv_file("stations.csv")
        stations_to_insert = []
        existing_stations = {s[0] for s in db.query(Station.station_code).all()}

        with open(station_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                code = row["station_code"].strip().upper()
                if code in existing_stations:
                    continue
                
                station = Station(
                    station_code=code,
                    station_name=row["station_name"].strip(),
                    zone=row.get("zone", "").strip() or None,
                    state=row.get("state", "").strip() or None,
                    address=row.get("address", "").strip() or None,
                    longitude=clean_float(row.get("longitude")),
                    latitude=clean_float(row.get("latitude"))
                )
                stations_to_insert.append(station)
                existing_stations.add(code)

        if stations_to_insert:
            # Insert in batches
            batch_size = 1000
            for i in range(0, len(stations_to_insert), batch_size):
                batch = stations_to_insert[i:i+batch_size]
                db.bulk_save_objects(batch)
                db.commit()
            print(f"Seeded {len(stations_to_insert)} new stations.")
        else:
            print("No new stations to seed.")

        # 2. Seed Trains
        print("Seeding trains...")
        train_path = find_csv_file("trains_final.csv")
        trains_to_insert = []
        existing_trains = {t[0] for t in db.query(Train.train_number).all()}

        with open(train_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                number = row["train_number"].strip()
                if number in existing_trains:
                    continue

                # Ensure from/to station codes exist in DB to prevent foreign key errors
                from_code = row["from_station_code"].strip().upper()
                to_code = row["to_station_code"].strip().upper()
                
                if from_code not in existing_stations or to_code not in existing_stations:
                    # Skip rows that don't match foreign key stations
                    continue

                train = Train(
                    train_number=number,
                    train_name=row["train_name"].strip(),
                    from_station_code=from_code,
                    from_station_name=row.get("from_station_name", "").strip() or None,
                    to_station_code=to_code,
                    to_station_name=row.get("to_station_name", "").strip() or None,
                    departure=row.get("departure", "00:00:00").strip(),
                    arrival=row.get("arrival", "00:00:00").strip(),
                    duration_h=clean_int(row.get("duration_h")),
                    duration_m=clean_int(row.get("duration_m")),
                    distance_km=clean_float(row.get("distance_km")),
                    train_type=row.get("train_type", "Exp").strip(),
                    zone=row.get("zone", "").strip() or None,
                    return_train=row.get("return_train", "").strip() or None,
                    has_1ac=clean_bool(row.get("has_1ac")),
                    has_2ac=clean_bool(row.get("has_2ac")),
                    has_3ac=clean_bool(row.get("has_3ac")),
                    has_sleeper=clean_bool(row.get("has_sleeper")),
                    has_chair_car=clean_bool(row.get("has_chair_car")),
                    has_first_class=clean_bool(row.get("has_first_class"))
                )
                trains_to_insert.append(train)
                existing_trains.add(number)

        if trains_to_insert:
            batch_size = 500
            for i in range(0, len(trains_to_insert), batch_size):
                batch = trains_to_insert[i:i+batch_size]
                db.bulk_save_objects(batch)
                db.commit()
            print(f"Seeded {len(trains_to_insert)} new trains.")
        else:
            print("No new trains to seed.")

        # Seed train stoppages
        seed_stoppages(db)

        # 3. Seed default seats for a few sample trains on upcoming dates
        # Note: In production/actual search, availability checks will dynamically
        # create Seat records on the fly if they don't exist. Here we pre-seed for a few
        # popular trains to ensure immediate test data.
        print("Pre-seeding default seat configurations...")
        sample_trains = db.query(Train).limit(5).all()
        today = date.today()
        seeded_seats_count = 0
        
        for train in sample_trains:
            for day_offset in range(5):
                journey_date = today + timedelta(days=day_offset)
                
                # Check classes supported by train
                classes_to_seed = []
                if train.has_sleeper:
                    classes_to_seed.append(("SL", 500, 250))
                if train.has_3ac:
                    classes_to_seed.append(("3A", 200, 0))
                if train.has_2ac:
                    classes_to_seed.append(("2A", 100, 0))
                if train.has_1ac:
                    classes_to_seed.append(("1A", 50, 0))
                if train.has_chair_car:
                    classes_to_seed.append(("CC", 150, 0))
                
                for coach_class, total_seats, rac_capacity in classes_to_seed:
                    # Check if already exists
                    exists = db.query(Seat).filter_by(
                        train_number=train.train_number,
                        journey_date=journey_date,
                        coach_class=coach_class
                    ).first()
                    
                    if not exists:
                        seat_record = Seat(
                            train_number=train.train_number,
                            journey_date=journey_date,
                            coach_class=coach_class,
                            total_seats=total_seats,
                            confirmed=0,
                            rac_count=0,
                            wl_count=0,
                            locked_seats=0
                        )
                        db.add(seat_record)
                        seeded_seats_count += 1
        
        db.commit()
        print(f"Pre-seeded {seeded_seats_count} seat records for next 5 days.")

    except Exception as e:
        print(f"Error seeding database: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
