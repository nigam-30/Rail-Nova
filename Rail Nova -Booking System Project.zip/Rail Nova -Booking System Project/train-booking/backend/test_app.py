import httpx
import random
import sys
from datetime import date, timedelta

BASE_URL = "http://localhost:8000"

def run_tests():
    print("====================================================")
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    # Start httpx client
    client = httpx.Client(base_url=BASE_URL)
    
    # Generate unique test user
    rand_id = random.randint(1000, 9999)
    email = f"testuser_{rand_id}@rail-nova.com"
    mobile = f"98765{rand_id:05d}"
    password = "SuperPassword123"
    name = "Integration Test User"
    
    print(f"1. TESTING REGISTRATION WITH OPTIONAL AADHAAR/PAN (LEAVING THEM OUT)")
    # Optional fields are not sent
    payload = {
        "email": email,
        "mobile": mobile,
        "password": password,
        "full_name": name
    }
    
    reg_res = client.post("/api/auth/register", json=payload)
    if reg_res.status_code != 201:
        print(f"❌ FAIL: Registration failed with status {reg_res.status_code}: {reg_res.text}")
        sys.exit(1)
    print(f"✅ SUCCESS: Registered user {email}")

    print("\n2. TESTING LOGIN")
    login_payload = {
        "email": email,
        "password": password
    }
    login_res = client.post("/api/auth/login", json=login_payload)
    if login_res.status_code != 200:
        print(f"❌ FAIL: Login failed with status {login_res.status_code}: {login_res.text}")
        sys.exit(1)
    
    token_data = login_res.json()
    token = token_data["access_token"]
    print("✅ SUCCESS: Logged in and received JWT token")
    
    # Authenticate client
    client.headers["Authorization"] = f"Bearer {token}"
    
    print("\n3. TESTING ME PROFILE ENDPOINT & PROPERTY MAPPING")
    me_res = client.get("/api/auth/me")
    if me_res.status_code != 200:
        print(f"❌ FAIL: Profile fetch failed: {me_res.text}")
        sys.exit(1)
    
    me_data = me_res.json()
    assert me_data["full_name"] == name
    assert me_data["email"] == email
    assert me_data["id_type"] is None
    assert me_data["id_number"] is None
    print("✅ SUCCESS: Profile fetched correctly. Optional Aadhaar/PAN are null in database.")

    print("\n4. TESTING STATION AUTOCOMPLETE (PRIORITIZING ADI EXPLICIT MATCH)")
    st_res = client.get("/api/stations/search?q=ADI")
    if st_res.status_code != 200:
        print(f"❌ FAIL: Station search failed: {st_res.text}")
        sys.exit(1)
        
    st_data = st_res.json()
    if not st_data or st_data[0]["station_code"] != "ADI":
        print(f"❌ FAIL: ADI is not the first autocomplete result! Got: {st_data}")
        sys.exit(1)
    print("✅ SUCCESS: Autocomplete successfully returned 'AHMEDABAD JN (ADI)' as the #1 prioritized result!")

    print("\n5. TESTING TRAIN SEARCH (ADI -> MSH)")
    train_res = client.get(f"/api/trains/search?from=ADI&to=MSH&date={tomorrow}")
    if train_res.status_code != 200:
        print(f"❌ FAIL: Train search failed: {train_res.text}")
        sys.exit(1)
        
    train_data = train_res.json()
    if not train_data:
        print("❌ FAIL: No trains found between ADI and MSH! Please check database seeding.")
        sys.exit(1)
        
    selected_train = train_data[0]
    train_num = selected_train["train"]["train_number"]
    train_name = selected_train["train"]["train_name"]
    print(f"✅ SUCCESS: Found {len(train_data)} trains! Selected train: {train_name} (#{train_num})")

    print("\n6. TESTING BOOKING INITIATION (LOCKING SL COACH SEATS)")
    booking_payload = {
        "train_number": train_num,
        "journey_date": tomorrow,
        "coach_class": "SL",
        "is_tatkal": False,
        "passengers": [
            {
                "name": "Passenger One",
                "age": 28,
                "gender": "MALE",
                "berth_pref": "Lower"
            },
            {
                "name": "Passenger Two",
                "age": 25,
                "gender": "FEMALE",
                "berth_pref": "Upper"
            }
        ]
    }
    
    book_res = client.post("/api/bookings", json=booking_payload)
    if book_res.status_code != 201:
        print(f"❌ FAIL: Booking creation failed: {book_res.text}")
        sys.exit(1)
        
    booking_data = book_res.json()
    pnr = booking_data["pnr"]
    booking_id = booking_data["id"]
    print(f"✅ SUCCESS: Created booking with ID {booking_id} holding PNR {pnr}")

    print("\n7. TESTING MOCK PAYMENT ORDER GENERATION")
    pay_order_res = client.post("/api/payments/create-order", json={"booking_id": booking_id})
    if pay_order_res.status_code != 200:
        print(f"❌ FAIL: Payment order failed: {pay_order_res.text}")
        sys.exit(1)
        
    order_data = pay_order_res.json()
    order_id = order_data["order_id"]
    print(f"✅ SUCCESS: Generated mock checkout order: {order_id}")

    print("\n8. TESTING MOCK PAYMENT SIGNATURE VERIFICATION")
    verify_payload = {
        "razorpay_order_id": order_id,
        "razorpay_payment_id": f"pay_mock_test_{rand_id}",
        "razorpay_signature": "mock_sig_hash_key"
    }
    verify_res = client.post("/api/payments/verify", json=verify_payload)
    if verify_res.status_code != 200:
        print(f"❌ FAIL: Verification failed: {verify_res.text}")
        sys.exit(1)
        
    verify_data = verify_res.json()
    assert verify_data["status"] == "SUCCESS"
    print("✅ SUCCESS: Secure payment checkout verified successfully!")

    print("\n9. TESTING BOOKING HISTORY LOGS & PNR INQUIRY")
    history_res = client.get("/api/bookings")
    if history_res.status_code != 200:
        print(f"❌ FAIL: Booking history failed: {history_res.text}")
        sys.exit(1)
        
    history_data = history_res.json()
    assert len(history_data) >= 1
    my_booking = next(b for b in history_data if b["pnr"] == pnr)
    assert my_booking["status"] == "CONFIRMED"
    print("✅ SUCCESS: Ticket status is successfully 'CONFIRMED' in history records!")

    pnr_res = client.get(f"/api/bookings/{pnr}")
    if pnr_res.status_code != 200:
        print(f"❌ FAIL: PNR inquiry failed: {pnr_res.text}")
        sys.exit(1)
    print("✅ SUCCESS: PNR status inquiry retrieved accurate passenger seat allocations!")

    print("\n10. TESTING TICKET CANCELLATION (RELEASING SL COACH SEATS)")
    cancel_res = client.delete(f"/api/bookings/{pnr}")
    if cancel_res.status_code != 200:
        print(f"❌ FAIL: Ticket cancellation failed: {cancel_res.text}")
        sys.exit(1)
        
    cancel_data = cancel_res.json()
    assert cancel_data["status"] == "CANCELLED"
    print("✅ SUCCESS: Reservation cancelled successfully, releasing seats to SQLite quota!")

    print("\n====================================================")
    print("🎉 ALL TESTS PASSED! BACKEND & DATABASE INTEGRATION PIPELINE IS 100% HEALTHY!")
    print("====================================================")

if __name__ == "__main__":
    run_tests()
