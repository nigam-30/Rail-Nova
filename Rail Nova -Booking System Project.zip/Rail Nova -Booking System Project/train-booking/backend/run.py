import uvicorn
import os

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    reload = os.environ.get("ENV", "development").lower() != "production"
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=reload)
