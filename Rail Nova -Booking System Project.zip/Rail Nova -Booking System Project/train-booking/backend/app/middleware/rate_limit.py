import time
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

# In-memory store: IP -> list of timestamps of login requests
login_attempts = {}

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        # Target the login endpoint specifically
        if request.url.path == "/api/auth/login" and request.method == "POST":
            client_ip = request.client.host if request.client else "unknown"
            now = time.time()
            
            # Retrieve and clean attempts older than 60 seconds
            attempts = login_attempts.get(client_ip, [])
            attempts = [t for t in attempts if now - t < 60]
            login_attempts[client_ip] = attempts
            
            if len(attempts) >= 5:
                return JSONResponse(
                    status_code=429,
                    content={
                        "detail": "Too many login attempts. Please try again in a minute.",
                        "code": "TOO_MANY_REQUESTS"
                    }
                )
            
            login_attempts[client_ip].append(now)
            
        return await call_next(request)
