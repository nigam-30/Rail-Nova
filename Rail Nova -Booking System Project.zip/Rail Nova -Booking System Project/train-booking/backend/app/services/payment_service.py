import uuid
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.models.payment import Payment
from app.models.booking import Booking
from app.models.user import User
from app.models.wallet_transaction import WalletTransaction
from app.schemas.payment import PaymentOrderOut, PaymentVerifyOut, PaymentVerify
from app.services.booking_service import BookingService

class PaymentService:
    @staticmethod
    def create_mock_order(db: Session, booking_id: str) -> PaymentOrderOut:
        booking = db.query(Booking).filter_by(id=booking_id).first()
        if not booking:
            raise HTTPException(status_code=404, detail="Booking not found")

        # Create mock order ID
        order_id = f"mock_order_{uuid.uuid4().hex[:12]}"
        
        payment = Payment(
            booking_id=booking_id,
            razorpay_order_id=order_id,
            amount=booking.total_fare,
            currency="INR",
            status="CREATED"
        )
        db.add(payment)
        db.commit()

        return PaymentOrderOut(
            order_id=order_id,
            amount=float(booking.total_fare),
            currency="INR"
        )

    @staticmethod
    def verify_mock_payment(db: Session, data: PaymentVerify) -> PaymentVerifyOut:
        payment = db.query(Payment).filter_by(razorpay_order_id=data.razorpay_order_id).first()
        if not payment:
            raise HTTPException(status_code=404, detail="Payment record not found")

        # Simulate success
        payment.status = "PAID"
        payment.razorpay_payment_id = data.razorpay_payment_id or f"mock_pay_{uuid.uuid4().hex[:12]}"
        db.commit()

        # Complete the booking (marks PAID, allocates seats, deletes lock)
        BookingService.complete_booking_payment(db, payment.booking_id, payment.razorpay_payment_id)

        return PaymentVerifyOut(
            status="SUCCESS",
            payment_id=payment.razorpay_payment_id
        )

    @staticmethod
    def pay_via_wallet(db: Session, user_id: str, booking_id: str) -> dict:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        booking = db.query(Booking).filter_by(id=booking_id).first()
        if not booking:
            raise HTTPException(status_code=404, detail="Booking not found")
        
        if booking.status != "PENDING":
            raise HTTPException(status_code=400, detail="Booking is not in pending status")

        if user.ewallet_balance is None:
            user.ewallet_balance = 0.0

        fare = float(booking.total_fare)
        if user.ewallet_balance < fare:
            raise HTTPException(status_code=400, detail=f"Insufficient eWallet balance (Available: ₹{user.ewallet_balance:.2f}). Please top up.")

        # Deduct
        user.ewallet_balance -= fare

        # Log Wallet Transaction
        wallet_tx = WalletTransaction(
            user_id=user_id,
            amount=-fare,
            type="PAYMENT",
            description=f"Ticket reservation checkout (PNR: {booking.pnr})"
        )
        db.add(wallet_tx)

        # Create mock payment row so transaction history reflects correctly
        order_id = f"wallet_order_{uuid.uuid4().hex[:12]}"
        payment_id = f"wallet_pay_{uuid.uuid4().hex[:12]}"
        
        payment = Payment(
            booking_id=booking_id,
            razorpay_order_id=order_id,
            razorpay_payment_id=payment_id,
            amount=booking.total_fare,
            currency="INR",
            status="PAID"
        )
        db.add(payment)
        db.commit()

        # Complete booking
        BookingService.complete_booking_payment(db, booking_id, payment_id)

        return {
            "status": "SUCCESS",
            "payment_id": payment_id,
            "balance": float(user.ewallet_balance)
        }

    @staticmethod
    def topup_wallet(db: Session, user_id: str, amount: float) -> dict:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        if amount <= 0.0:
            raise HTTPException(status_code=400, detail="Deposit amount must be greater than zero")

        if user.ewallet_balance is None:
            user.ewallet_balance = 0.0

        user.ewallet_balance += amount

        # Log Wallet Transaction
        wallet_tx = WalletTransaction(
            user_id=user_id,
            amount=amount,
            type="DEPOSIT",
            description="Loaded money into eWallet account"
        )
        db.add(wallet_tx)
        db.commit()

        return {
            "status": "SUCCESS",
            "amount": amount,
            "balance": float(user.ewallet_balance)
        }

    @staticmethod
    def get_wallet_history(db: Session, user_id: str) -> dict:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        txs = db.query(WalletTransaction).filter_by(user_id=user_id).order_by(WalletTransaction.created_at.desc()).all()

        return {
            "balance": float(user.ewallet_balance or 0.0),
            "transactions": [
                {
                    "id": t.id,
                    "amount": float(t.amount),
                    "type": t.type,
                    "description": t.description,
                    "created_at": t.created_at
                }
                for t in txs
            ]
        }
