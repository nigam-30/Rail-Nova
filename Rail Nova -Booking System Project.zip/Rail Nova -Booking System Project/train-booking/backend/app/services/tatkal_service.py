from sqlalchemy.orm import Session
from datetime import date, datetime, time, timedelta
from fastapi import HTTPException, status
from app.models.tatkal_queue import TatkalQueue

# Global dictionary to store tatkal WebSocket connections for live queue position broadcasts
active_tatkal_ws_connections = {}

async def broadcast_tatkal_updates(train_number: str, journey_date: str, coach_class: str):
    key = f"{train_number}:{journey_date}:{coach_class}"
    if key in active_tatkal_ws_connections:
        dead_connections = []
        for connection in active_tatkal_ws_connections[key]:
            try:
                # We can broadcast a pulse signal so the client fetches its latest position
                await connection.send_json({"type": "queue_ping"})
            except Exception:
                dead_connections.append(connection)
        
        # Clean up dead connections
        for conn in dead_connections:
            active_tatkal_ws_connections[key].remove(conn)

class TatkalService:
    @staticmethod
    def is_tatkal_window_open(journey_date: date, coach_class: str) -> tuple[bool, str]:
        now = datetime.now()
        c_class = coach_class.strip().upper()
        
        # Identify AC vs Non-AC classes
        ac_classes = {"1A", "1AC", "2A", "2AC", "3A", "3AC", "3E", "CC", "EC", "EA", "VS"}
        is_ac = c_class in ac_classes
        
        opening_time = time(10, 0, 0) if is_ac else time(11, 0, 0)
        opening_date = journey_date - timedelta(days=1)
        opening_datetime = datetime.combine(opening_date, opening_time)
        
        if now < opening_datetime:
            class_type = "AC" if is_ac else "Non-AC"
            open_str = opening_datetime.strftime("%Y-%m-%d at %I:%M %p")
            time_str = "10:00 AM" if is_ac else "11:00 AM"
            msg = f"Tatkal booking for {class_type} class {coach_class} opens exactly 1 day before journey at {time_str}. It will open on {open_str}."
            return False, msg
            
        return True, "Tatkal booking is open."

    @staticmethod
    def join_queue(db: Session, user_id: str, train_number: str, journey_date: date, coach_class: str) -> TatkalQueue:
        # Check if already joined and active/waiting
        existing = db.query(TatkalQueue).filter(
            TatkalQueue.user_id == user_id,
            TatkalQueue.train_number == train_number,
            TatkalQueue.journey_date == journey_date,
            TatkalQueue.coach_class == coach_class,
            TatkalQueue.status.in_(["WAITING", "ACTIVE"])
        ).first()

        if existing:
            return existing

        # Count total in queue for this train/date/class
        total_waiting = db.query(TatkalQueue).filter(
            TatkalQueue.train_number == train_number,
            TatkalQueue.journey_date == journey_date,
            TatkalQueue.coach_class == coach_class,
            TatkalQueue.status == "WAITING"
        ).count()

        position = total_waiting + 1
        now = datetime.now()
        
        # Check if the tatkal window is open
        is_open, msg = TatkalService.is_tatkal_window_open(journey_date, coach_class)
        if not is_open:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=msg
            )
        
        if position <= 50:
            status_val = "ACTIVE"
            window_start = now
            window_end = now + timedelta(minutes=10)
        else:
            status_val = "WAITING"
            window_start = None
            window_end = None

        queue_entry = TatkalQueue(
            user_id=user_id,
            train_number=train_number,
            journey_date=journey_date,
            coach_class=coach_class,
            position=position,
            status=status_val,
            window_start=window_start,
            window_end=window_end
        )
        
        db.add(queue_entry)
        db.commit()
        db.refresh(queue_entry)
        
        return queue_entry

    @staticmethod
    def get_status(db: Session, user_id: str, train_number: str, journey_date: date, coach_class: str) -> dict:
        entry = db.query(TatkalQueue).filter(
            TatkalQueue.user_id == user_id,
            TatkalQueue.train_number == train_number,
            TatkalQueue.journey_date == journey_date,
            TatkalQueue.coach_class == coach_class
        ).order_by(TatkalQueue.joined_at.desc()).first()

        if not entry:
            return {"status": "NOT_JOINED"}

        # Calculate dynamic position
        # Position is the count of rows for this train/date/class with status WAITING and joined_at < entry.joined_at
        if entry.status == "WAITING":
            earlier_count = db.query(TatkalQueue).filter(
                TatkalQueue.train_number == train_number,
                TatkalQueue.journey_date == journey_date,
                TatkalQueue.coach_class == coach_class,
                TatkalQueue.status == "WAITING",
                TatkalQueue.joined_at < entry.joined_at
            ).count()
            position = earlier_count + 1
        else:
            position = 0

        # Calculate time remaining if ACTIVE
        time_remaining_seconds = 0
        if entry.status == "ACTIVE" and entry.window_end:
            time_remaining = entry.window_end - datetime.now()
            time_remaining_seconds = max(0, int(time_remaining.total_seconds()))

        return {
            "id": entry.id,
            "status": entry.status,
            "position": position,
            "window_start": entry.window_start,
            "window_end": entry.window_end,
            "time_remaining_seconds": time_remaining_seconds
        }
