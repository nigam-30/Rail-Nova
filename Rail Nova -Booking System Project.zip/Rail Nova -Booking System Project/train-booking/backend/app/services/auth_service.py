from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from app.models.user import User
from app.schemas.auth import UserRegister, UserProfileUpdate, ChangePassword
from app.utils.security import get_password_hash, verify_password

class AuthService:
    @staticmethod
    def register(db: Session, schema: UserRegister) -> User:
        # Verify uniqueness
        if db.query(User).filter_by(email=schema.email).first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email address is already registered."
            )
        if db.query(User).filter_by(mobile=schema.mobile).first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Mobile number is already registered."
            )
        
        user = User(
            email=schema.email,
            mobile=schema.mobile,
            password_hash=get_password_hash(schema.password),
            full_name=schema.full_name,
            date_of_birth=schema.date_of_birth,
            gender=schema.gender,
            id_type=schema.id_type,
            id_number=schema.id_number
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    @staticmethod
    def authenticate(db: Session, email: str, password: str) -> User:
        user = db.query(User).filter_by(email=email).first()
        if not user or not verify_password(password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password."
            )
        return user

    @staticmethod
    def get_profile(db: Session, user_id: str) -> User:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found."
            )
        return user

    @staticmethod
    def update_profile(db: Session, user_id: str, schema: UserProfileUpdate) -> User:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found."
            )
        
        if schema.full_name is not None:
            user.full_name = schema.full_name
        if schema.mobile is not None:
            # Check mobile uniqueness if changing
            if schema.mobile != user.mobile:
                if db.query(User).filter_by(mobile=schema.mobile).first():
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Mobile number already in use by another account."
                    )
                user.mobile = schema.mobile
        if schema.date_of_birth is not None:
            user.date_of_birth = schema.date_of_birth
        if schema.gender is not None:
            user.gender = schema.gender
        if schema.id_type is not None:
            user.id_type = schema.id_type
        if schema.id_number is not None:
            user.id_number = schema.id_number
            
        db.commit()
        db.refresh(user)
        return user

    @staticmethod
    def change_password(db: Session, user_id: str, schema: ChangePassword) -> None:
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found."
            )
        
        if not verify_password(schema.old_password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Incorrect old password."
            )
            
        user.password_hash = get_password_hash(schema.new_password)
        db.commit()
