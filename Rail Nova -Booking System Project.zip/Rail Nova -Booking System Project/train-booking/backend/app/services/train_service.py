from sqlalchemy import func
from sqlalchemy.orm import Session, aliased
from datetime import date, datetime, timedelta
from typing import List, Optional
from app.models.station import Station
from app.models.train import Train
from app.models.seat import Seat
from app.models.seat_lock import SeatLock
from app.models.booking import Booking
from app.models.passenger import Passenger
from app.models.train_stoppage import TrainStoppage
from app.schemas.train import TrainOut, ClassAvailability, TrainSearchCardOut, SeatAvailabilityOut

class TrainService:
    @staticmethod
    def search_stations(db: Session, query: str) -> List[Station]:
        if not query:
            return []
        
        query_clean = query.strip().upper()
        
        # 1. Exact match on station code first
        exact_code = db.query(Station).filter(Station.station_code == query_clean).all()
        
        # 2. Exact start matches on station code
        prefix_code = db.query(Station).filter(
            Station.station_code.like(f"{query_clean}%"),
            Station.station_code != query_clean
        ).limit(10 - len(exact_code)).all()
        
        # 3. Partial matches on station name
        results = exact_code + prefix_code
        if len(results) < 10:
            existing_codes = [s.station_code for s in results]
            name_matches = db.query(Station).filter(
                Station.station_name.like(f"%{query}%")
            ).all()
            
            # Filter name matches that aren't already in results to avoid duplicates
            for nm in name_matches:
                if nm.station_code not in existing_codes:
                    results.append(nm)
                    existing_codes.append(nm.station_code)
                    if len(results) >= 10:
                        break
            
        return results[:10]

    @staticmethod
    def calculate_fare(distance_km: float, coach_class: str, is_tatkal: bool = False) -> float:
        # Standardize coach class
        c_class = coach_class.strip().upper()
        
        # Standard base fare multipliers for all 11 classes
        multipliers = {
            "1A": 3.50,
            "1AC": 3.50,
            "2A": 2.00,
            "2AC": 2.00,
            "3A": 1.20,
            "3AC": 1.20,
            "3E": 1.10,
            "EA": 3.00,
            "EC": 3.00,
            "CC": 0.80,
            "FC": 1.10,
            "SL": 0.50,
            "2S": 0.35,
            "VS": 1.00
        }
        
        multiplier = multipliers.get(c_class, 0.50)
        base_fare = distance_km * multiplier
        
        if is_tatkal:
            # Tatkal charges rules: (surcharge percentage, minimum limit, maximum limit)
            # Second Sitting (2S): 10% of basic fare, Min ₹10, Max ₹15
            # Sleeper (SL): 30% of basic fare, Min ₹100, Max ₹200
            # AC Chair Car (CC): 30% of basic fare, Min ₹125, Max ₹225
            # AC 3 Tier (3A/3AC/3E): 30% of basic fare, Min ₹300, Max ₹400
            # AC 2 Tier (2A/2AC): 30% of basic fare, Min ₹400, Max ₹500
            # First AC / Premium Classes: 30% of basic fare, Min ₹400, Max ₹500
            tatkal_rules = {
                "2S": (0.10, 10.0, 15.0),
                "SL": (0.30, 100.0, 200.0),
                "CC": (0.30, 125.0, 225.0),
                "3A": (0.30, 300.0, 400.0),
                "3AC": (0.30, 300.0, 400.0),
                "3E": (0.30, 300.0, 400.0),
                "2A": (0.30, 400.0, 500.0),
                "2AC": (0.30, 400.0, 500.0),
                "1A": (0.30, 400.0, 500.0),
                "1AC": (0.30, 400.0, 500.0),
                "FC": (0.30, 400.0, 500.0),
                "EC": (0.30, 400.0, 500.0),
                "EA": (0.30, 400.0, 500.0),
                "VS": (0.30, 400.0, 500.0)
            }
            
            rule = tatkal_rules.get(c_class, (0.30, 100.0, 300.0))
            pct, min_surcharge, max_surcharge = rule
            
            tatkal_surcharge = base_fare * pct
            tatkal_surcharge = max(min(tatkal_surcharge, max_surcharge), min_surcharge)
            
            base_fare += tatkal_surcharge
            convenience_fee = 30.0
        else:
            convenience_fee = 15.0
            
        fare = max(base_fare, 50.0) + convenience_fee
        return round(fare, 2)

    @staticmethod
    def get_active_locks_count(db: Session, train_number: str, journey_date: date, coach_class: str) -> int:
        now = datetime.now()
        # Get count of passengers who have an active lock on their booking
        count = db.query(Passenger).join(Booking).join(
            SeatLock, Booking.id == SeatLock.id
        ).filter(
            Booking.train_number == train_number,
            Booking.journey_date == journey_date,
            Booking.coach_class == coach_class,
            Booking.status == "PENDING",
            SeatLock.expires_at > now
        ).count()
        return count

    @staticmethod
    def get_or_create_seat_record(db: Session, train_number: str, journey_date: date, coach_class: str) -> Optional[Seat]:
        # Enforce that the train supports this class
        train = db.query(Train).filter_by(train_number=train_number).first()
        if not train:
            return None
            
        supports = False
        default_seats = 0
        
        # Map all 11 standard Rail Nova class abbreviations to train properties and default capacities
        class_mapping = {
            "1A": (train.has_1ac, 50),
            "1AC": (train.has_1ac, 50),
            "2A": (train.has_2ac, 100),
            "2AC": (train.has_2ac, 100),
            "3A": (train.has_3ac, 200),
            "3AC": (train.has_3ac, 200),
            "3E": (train.has_3ac, 200),  # AC 3 Economy maps to 3AC properties
            "EA": (train.has_chair_car or train.has_1ac, 50),  # Executive Anubhuti maps to CC/1A properties
            "EC": (train.has_chair_car or train.has_1ac, 50),  # Executive Chair Car maps to CC/1A properties
            "CC": (train.has_chair_car, 150),
            "FC": (train.has_first_class or train.has_2ac, 100),  # First Class maps to FC/2A properties
            "SL": (train.has_sleeper, 500),
            "2S": (train.has_sleeper or train.has_chair_car, 500),  # Second Seating maps to Sleeper/CC properties
            "VS": (train.has_chair_car, 150),  # Vistadome maps to CC properties
        }

        mapped = class_mapping.get(coach_class.strip().upper())
        if mapped:
            supports, default_seats = mapped[0], mapped[1]
            
        if not supports:
            return None

        # Fetch or insert
        seat = db.query(Seat).filter_by(
            train_number=train_number,
            journey_date=journey_date,
            coach_class=coach_class
        ).first()

        if not seat:
            seat = Seat(
                train_number=train_number,
                journey_date=journey_date,
                coach_class=coach_class,
                total_seats=default_seats,
                confirmed=0,
                rac_count=0,
                wl_count=0,
                locked_seats=0
            )
            db.add(seat)
            db.commit()
            db.refresh(seat)
            
        return seat

    @staticmethod
    def get_class_availability(db: Session, train: Train, journey_date: date, coach_class: str, distance_km: Optional[float] = None) -> Optional[ClassAvailability]:
        seat = TrainService.get_or_create_seat_record(db, train.train_number, journey_date, coach_class)
        if not seat:
            return None

        active_locks = TrainService.get_active_locks_count(db, train.train_number, journey_date, coach_class)
        
        # Calculate availability numbers
        total = seat.total_seats
        confirmed = seat.confirmed + active_locks
        
        dist = distance_km if distance_km is not None else (train.distance_km or 100.0)
        fare = TrainService.calculate_fare(dist, coach_class)

        # SL supports RAC
        if coach_class == "SL":
            rac_capacity = int(total * 0.50) # 50% of total
            if confirmed < total:
                available_seats = total - confirmed
                status = f"AVAILABLE {available_seats}"
            elif seat.rac_count < rac_capacity:
                available_seats = rac_capacity - seat.rac_count
                status = f"RAC {seat.rac_count + 1}"
            else:
                status = f"WL {seat.wl_count + 1}"
                available_seats = seat.wl_count + 1
        else:
            if confirmed < total:
                available_seats = total - confirmed
                status = f"AVAILABLE {available_seats}"
            else:
                status = f"WL {seat.wl_count + 1}"
                available_seats = seat.wl_count + 1

        return ClassAvailability(
            coach_class=coach_class,
            available_seats=available_seats,
            rac_count=seat.rac_count,
            wl_count=seat.wl_count,
            fare=fare,
            status=status
        )

    @staticmethod
    def search_trains(db: Session, from_code: str, to_code: str, journey_date: date, coach_class: Optional[str] = None) -> List[TrainSearchCardOut]:
        from_code_clean = from_code.strip().upper()
        to_code_clean = to_code.strip().upper()

        # Check if stoppages exist in database
        stoppages_exist = db.query(TrainStoppage).first() is not None

        if not stoppages_exist:
            # Fallback to direct terminal matching if stoppages table is empty
            query = db.query(Train).filter(
                Train.from_station_code == from_code_clean,
                Train.to_station_code == to_code_clean
            )
            trains_data = [(t, None, None) for t in query.all()]
        else:
            # Query using stoppages self-join
            StoppageFrom = aliased(TrainStoppage)
            StoppageTo = aliased(TrainStoppage)
            
            query = db.query(Train, StoppageFrom, StoppageTo).join(
                StoppageFrom, Train.train_number == StoppageFrom.train_number
            ).join(
                StoppageTo, Train.train_number == StoppageTo.train_number
            ).filter(
                StoppageFrom.station_code == from_code_clean,
                StoppageTo.station_code == to_code_clean,
                StoppageFrom.stop_number < StoppageTo.stop_number
            )
            trains_data = query.all()

        results = []
        for item in trains_data:
            train = item[0]
            stop_from = item[1]
            stop_to = item[2]

            # Calculate intermediate distance and duration if stop info is available
            if stop_from and stop_to:
                total_distance = train.distance_km or 100.0
                max_stop = db.query(func.max(TrainStoppage.stop_number)).filter(
                    TrainStoppage.train_number == train.train_number
                ).scalar() or stop_to.stop_number
                
                if max_stop > 1:
                    stops_diff = stop_to.stop_number - stop_from.stop_number
                    distance_km = round((stops_diff / max_stop) * total_distance, 2)
                else:
                    distance_km = total_distance

                # Calculate duration from stoppage arrival/departure times
                dep_time_str = stop_from.departure or train.departure
                arr_time_str = stop_to.arrival or train.arrival

                def parse_time(t_str):
                    if not t_str:
                        return None
                    for fmt in ("%H:%M:%S", "%H:%M"):
                        try:
                            return datetime.strptime(t_str.strip(), fmt).time()
                        except ValueError:
                            continue
                    return None

                dep_time = parse_time(dep_time_str)
                arr_time = parse_time(arr_time_str)

                if dep_time and arr_time:
                    dep_dt = datetime(2000, 1, stop_from.day or 1, dep_time.hour, dep_time.minute, dep_time.second)
                    arr_dt = datetime(2000, 1, stop_to.day or 1, arr_time.hour, arr_time.minute, arr_time.second)
                    if arr_dt < dep_dt:
                        arr_dt += timedelta(days=1)
                    duration = arr_dt - dep_dt
                    duration_h = duration.seconds // 3600 + duration.days * 24
                    duration_m = (duration.seconds % 3600) // 60
                else:
                    duration_h = train.duration_h
                    duration_m = train.duration_m

                train_out = TrainOut(
                    train_number=train.train_number,
                    train_name=train.train_name,
                    from_station_code=from_code_clean,
                    from_station_name=stop_from.station_name,
                    to_station_code=to_code_clean,
                    to_station_name=stop_to.station_name,
                    departure=dep_time_str,
                    arrival=arr_time_str,
                    duration_h=duration_h,
                    duration_m=duration_m,
                    distance_km=distance_km,
                    train_type=train.train_type,
                    zone=train.zone,
                    has_1ac=train.has_1ac,
                    has_2ac=train.has_2ac,
                    has_3ac=train.has_3ac,
                    has_sleeper=train.has_sleeper,
                    has_chair_car=train.has_chair_car,
                    has_first_class=train.has_first_class
                )
            else:
                distance_km = train.distance_km or 100.0
                train_out = TrainOut.from_orm(train)

            classes_to_check = ["1A", "2A", "3A", "SL", "CC"]
            if coach_class:
                classes_to_check = [coach_class]

            availabilities = []
            for c_class in classes_to_check:
                avail = TrainService.get_class_availability(db, train, journey_date, c_class, distance_km=distance_km)
                if avail:
                    availabilities.append(avail)

            if not availabilities:
                continue

            results.append(TrainSearchCardOut(
                train=train_out,
                availabilities=availabilities
            ))

        return results
