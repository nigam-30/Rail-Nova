from sqlalchemy.orm import Session
from datetime import date
from app.models.seat import Seat

class SeatService:
    @staticmethod
    def get_availability(db: Session, train_number: str, journey_date: date, coach_class: str) -> dict:
        from app.services.train_service import TrainService
        seat = TrainService.get_or_create_seat_record(db, train_number, journey_date, coach_class)
        if not seat:
            return {}
        return {
            "total_seats": seat.total_seats,
            "confirmed": seat.confirmed,
            "rac_count": seat.rac_count,
            "wl_count": seat.wl_count,
            "locked_seats": seat.locked_seats
        }
