import random
from datetime import date, datetime, timedelta
from sqlalchemy.orm import Session
from fastapi import HTTPException, status, BackgroundTasks
from app.database import SessionLocal
from app.models.booking import Booking
from app.models.passenger import Passenger
from app.models.seat import Seat
from app.models.seat_lock import SeatLock
from app.models.train import Train
from app.schemas.booking import BookingCreate
from app.utils.helpers import generate_unique_pnr
from app.services.train_service import TrainService
from app.services.seat_service import SeatService

# Global dictionary to store active WebSocket connections for broadcasts
# Will be populated by the websocket router
active_ws_connections = {}

async def broadcast_seat_updates(train_number: str, journey_date: str):
    # Retrieve all connections for this train and date
    key = f"{train_number}:{journey_date}"
    if key in active_ws_connections:
        dead_connections = []
        for connection in active_ws_connections[key]:
            try:
                # We can broadcast a simple refresh trigger or current availability JSON
                await connection.send_json({"type": "availability_update", "train_number": train_number, "date": journey_date})
            except Exception:
                dead_connections.append(connection)
        
        # Clean up dead connections
        for conn in dead_connections:
            active_ws_connections[key].remove(conn)

class BookingService:
    @staticmethod
    def get_coach_prefix(coach_class: str) -> str:
        coach_class = coach_class.strip().upper()
        return {
            "1A": "H",
            "1AC": "H",
            "2A": "A",
            "2AC": "A",
            "3A": "B",
            "3AC": "B",
            "3E": "M",  # AC 3 Economy is 'M'
            "SL": "S",  # Sleeper is 'S'
            "2S": "D",  # Second Sitting is 'D'
            "CC": "C",  # AC Chair Car is 'C'
            "EC": "E",  # Executive Chair Car is 'E'
            "EA": "E",  # Executive Anubhuti is 'E'
            "FC": "F",  # First Class is 'F'
            "VS": "V"   # Vistadome is 'V'
        }.get(coach_class, "S")

    @staticmethod
    def get_coach_capacity(coach_class: str) -> int:
        coach_class = coach_class.strip().upper()
        if coach_class in {"1A", "1AC"}:
            return 24  # AC First Class has 24 berths
        elif coach_class in {"2A", "2AC"}:
            return 48  # AC 2-Tier has 48 berths
        elif coach_class in {"CC"}:
            return 78  # AC Chair Car has 78 seats
        return 72

    @staticmethod
    def initiate_booking(db: Session, user_id: str, schema: BookingCreate) -> Booking:
        train = db.query(Train).filter_by(train_number=schema.train_number).first()
        if not train:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Train not found")
        
        # Verify Tatkal window is open if user requests Tatkal booking
        if schema.is_tatkal:
            from app.services.tatkal_service import TatkalService
            is_open, msg = TatkalService.is_tatkal_window_open(schema.journey_date, schema.coach_class)
            if not is_open:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=msg
                )
        
        # 1. Get or create seat availability record
        seat_rec = TrainService.get_or_create_seat_record(db, schema.train_number, schema.journey_date, schema.coach_class)
        if not seat_rec:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Coach class not supported by this train")

        # 2. Get active locks count
        active_locks = TrainService.get_active_locks_count(db, schema.train_number, schema.journey_date, schema.coach_class)

        # Determine from and to station codes
        from_code = schema.from_station.strip().upper() if schema.from_station else train.from_station_code
        to_code = schema.to_station.strip().upper() if schema.to_station else train.to_station_code

        # Calculate distance
        distance_km = train.distance_km or 100.0
        if schema.from_station and schema.to_station:
            from app.models.train_stoppage import TrainStoppage
            from sqlalchemy import func
            stop_from = db.query(TrainStoppage).filter_by(train_number=schema.train_number, station_code=from_code).first()
            stop_to = db.query(TrainStoppage).filter_by(train_number=schema.train_number, station_code=to_code).first()
            if stop_from and stop_to and stop_from.stop_number < stop_to.stop_number:
                max_stop = db.query(func.max(TrainStoppage.stop_number)).filter(
                    TrainStoppage.train_number == schema.train_number
                ).scalar() or stop_to.stop_number
                
                if max_stop > 1:
                    stops_diff = stop_to.stop_number - stop_from.stop_number
                    distance_km = (stops_diff / max_stop) * (train.distance_km or 100.0)

        # 3. Calculate fare per passenger
        single_fare = TrainService.calculate_fare(distance_km, schema.coach_class, schema.is_tatkal)
        total_fare = single_fare * len(schema.passengers)
        
        # Generate PNR
        pnr = generate_unique_pnr(db)

        booking = Booking(
            pnr=pnr,
            user_id=user_id,
            train_number=schema.train_number,
            journey_date=schema.journey_date,
            from_station=from_code,
            to_station=to_code,
            coach_class=schema.coach_class,
            is_tatkal=schema.is_tatkal,
            total_fare=total_fare,
            status="PENDING",
            payment_status="UNPAID"
        )
        
        db.add(booking)
        db.commit() # commit so booking gets an ID

        # 4. Assign passenger statuses (CNF, RAC, WL)
        confirmed_count = seat_rec.confirmed + active_locks
        rac_capacity = int(seat_rec.total_seats * 0.50) if schema.coach_class == "SL" else 0
        
        # Track local counters for this booking batch
        local_confirmed = confirmed_count
        local_rac = seat_rec.rac_count
        local_wl = seat_rec.wl_count

        for p_schema in schema.passengers:
            if schema.coach_class == "SL":
                if local_confirmed < seat_rec.total_seats:
                    p_status = "CNF"
                    local_confirmed += 1
                elif local_rac < rac_capacity:
                    p_status = "RAC"
                    local_rac += 1
                else:
                    p_status = "WL"
                    local_wl += 1
            else:
                if local_confirmed < seat_rec.total_seats:
                    p_status = "CNF"
                    local_confirmed += 1
                else:
                    p_status = "WL"
                    local_wl += 1

            passenger = Passenger(
                booking_id=booking.id,
                name=p_schema.name,
                age=p_schema.age,
                gender=p_schema.gender,
                berth_pref=p_schema.berth_pref,
                status=p_status
            )
            db.add(passenger)
        
        # Create seat lock row (ID matches booking ID)
        lock = SeatLock(
            id=booking.id,
            train_number=schema.train_number,
            journey_date=str(schema.journey_date),
            coach_class=schema.coach_class,
            user_id=user_id,
            expires_at=datetime.now() + timedelta(minutes=10)
        )
        db.add(lock)
        db.commit()
        db.refresh(booking)
        
        return booking

    @staticmethod
    def complete_booking_payment(db: Session, booking_id: str, payment_id: str) -> Booking:
        booking = db.query(Booking).filter_by(id=booking_id).first()
        if not booking:
            raise HTTPException(status_code=404, detail="Booking not found")

        if booking.payment_status == "PAID":
            return booking

        # Set PAID
        booking.payment_status = "PAID"
        
        # Update passenger counts in Seat DB record
        seat_rec = db.query(Seat).filter_by(
            train_number=booking.train_number,
            journey_date=booking.journey_date,
            coach_class=booking.coach_class
        ).first()

        cnf_passengers = [p for p in booking.passengers if p.status == "CNF"]
        rac_passengers = [p for p in booking.passengers if p.status == "RAC"]
        wl_passengers = [p for p in booking.passengers if p.status == "WL"]

        seat_rec.confirmed += len(cnf_passengers)
        seat_rec.rac_count += len(rac_passengers)
        seat_rec.wl_count += len(wl_passengers)

        # Recalculate PNR status
        if wl_passengers:
            booking.status = "WL"
            booking.wl_number = wl_passengers[0].booking.wl_number or 1 # standard placeholder
        elif rac_passengers:
            booking.status = "RAC"
        else:
            booking.status = "CONFIRMED"

        # Assign Seat Numbers based on authentic Indian Railways coach prefixes and capacities
        c_class = booking.coach_class.strip().upper()
        coach_prefix = BookingService.get_coach_prefix(c_class)
        coach_capacity = BookingService.get_coach_capacity(c_class)

        original_confirmed = seat_rec.confirmed - len(cnf_passengers)
        for idx, p in enumerate(cnf_passengers):
            seat_idx = original_confirmed + idx
            
            coach_idx = (seat_idx // coach_capacity) + 1
            seat_num_in_coach = (seat_idx % coach_capacity) + 1
            
            p.coach_number = f"{coach_prefix}{coach_idx}"
            p.seat_number = f"{seat_num_in_coach}"

        for idx, p in enumerate(rac_passengers):
            # RAC share side lowers
            coach_num = f"{coach_prefix}1"
            seat_num = f"SUB_{seat_rec.rac_count - len(rac_passengers) + idx + 1}"
            p.coach_number = coach_num
            p.seat_number = seat_num

        # Remove lock
        db.query(SeatLock).filter_by(id=booking.id).delete()
        
        db.commit()
        db.refresh(booking)
        
        return booking

    @staticmethod
    def cancel_booking(db: Session, pnr: str, user_id: str, background_tasks: BackgroundTasks) -> Booking:
        booking = db.query(Booking).filter_by(pnr=pnr).first()
        if not booking:
            raise HTTPException(status_code=404, detail="Booking not found")

        if booking.user_id != user_id:
            raise HTTPException(status_code=403, detail="Unauthorized to cancel this booking")

        if booking.status == "CANCELLED":
            raise HTTPException(status_code=400, detail="Booking already cancelled")

        if booking.journey_date <= date.today():
            raise HTTPException(status_code=400, detail="Cannot cancel journey on or after departure date")

        booking.status = "CANCELLED"
        if booking.payment_status == "PAID":
            booking.payment_status = "REFUNDED"
            
            # Check if this booking was paid via eWallet
            from app.models.payment import Payment
            payment = db.query(Payment).filter_by(booking_id=booking.id, status="PAID").first()
            if payment and payment.razorpay_payment_id and payment.razorpay_payment_id.startswith("wallet_pay_"):
                # Refund directly to user's eWallet balance!
                from app.models.user import User
                from app.models.wallet_transaction import WalletTransaction
                user = db.query(User).filter_by(id=booking.user_id).first()
                if user:
                    if user.ewallet_balance is None:
                        user.ewallet_balance = 0.0
                    
                    refund_val = float(booking.total_fare)
                    user.ewallet_balance += refund_val
                    
                    # Log Wallet transaction
                    wallet_tx = WalletTransaction(
                        user_id=booking.user_id,
                        amount=refund_val,
                        type="REFUND",
                        description=f"Ticket reservation refund (PNR: {booking.pnr})"
                    )
                    db.add(wallet_tx)

        # Update seat records
        seat_rec = db.query(Seat).filter_by(
            train_number=booking.train_number,
            journey_date=booking.journey_date,
            coach_class=booking.coach_class
        ).first()

        for p in booking.passengers:
            if p.status == "CNF":
                seat_rec.confirmed = max(0, seat_rec.confirmed - 1)
            elif p.status == "RAC":
                seat_rec.rac_count = max(0, seat_rec.rac_count - 1)
            elif p.status == "WL":
                seat_rec.wl_count = max(0, seat_rec.wl_count - 1)
            
            p.status = "CANCELLED"
            p.seat_number = None
            p.coach_number = None

        db.commit()

        # Queue waitlist promotion background task
        background_tasks.add_task(
            BookingService.promote_waitlist_bg,
            booking.train_number,
            booking.journey_date,
            booking.coach_class
        )

        return booking

    @staticmethod
    def promote_waitlist_bg(train_number: str, journey_date: date, coach_class: str):
        # Run inside a clean DB session
        db = SessionLocal()
        try:
            seat = db.query(Seat).filter_by(
                train_number=train_number,
                journey_date=journey_date,
                coach_class=coach_class
            ).first()
            if not seat:
                return

            # Retrieve all bookings for this train/date/class that are PAID and not CANCELLED
            # Ordered by created_at first-come, first-served
            bookings_list = db.query(Booking).filter(
                Booking.train_number == train_number,
                Booking.journey_date == journey_date,
                Booking.coach_class == coach_class,
                Booking.payment_status == "PAID",
                Booking.status != "CANCELLED"
            ).order_by(Booking.created_at.asc()).all()
            
            # Extract all passengers with RAC or WL status
            rac_passengers = []
            wl_passengers = []
            
            for b in bookings_list:
                for p in b.passengers:
                    if p.status == "RAC":
                        rac_passengers.append(p)
                    elif p.status == "WL":
                        wl_passengers.append(p)

            # Sort passengers by booking created_at to preserve queue order
            rac_passengers.sort(key=lambda x: x.booking.created_at)
            wl_passengers.sort(key=lambda x: x.booking.created_at)

            # Max capacities
            rac_capacity = int(seat.total_seats * 0.50) if coach_class == "SL" else 0
            coach_prefix = BookingService.get_coach_prefix(coach_class)
            coach_capacity = BookingService.get_coach_capacity(coach_class)

            # 1. Promote RAC passengers to CNF if slot is free
            promoted_rac_count = 0
            while rac_passengers and seat.confirmed < seat.total_seats:
                p = rac_passengers.pop(0)
                p.status = "CNF"
                
                seat_idx = seat.confirmed
                coach_idx = (seat_idx // coach_capacity) + 1
                seat_num_in_coach = (seat_idx % coach_capacity) + 1
                
                p.coach_number = f"{coach_prefix}{coach_idx}"
                p.seat_number = f"{seat_num_in_coach}"
                
                seat.confirmed += 1
                seat.rac_count = max(0, seat.rac_count - 1)
                promoted_rac_count += 1

            # 2. Promote WL passengers to RAC or CNF
            while wl_passengers:
                p = wl_passengers.pop(0)
                if seat.confirmed < seat.total_seats:
                    p.status = "CNF"
                    
                    seat_idx = seat.confirmed
                    coach_idx = (seat_idx // coach_capacity) + 1
                    seat_num_in_coach = (seat_idx % coach_capacity) + 1
                    
                    p.coach_number = f"{coach_prefix}{coach_idx}"
                    p.seat_number = f"{seat_num_in_coach}"
                    
                    seat.confirmed += 1
                    seat.wl_count = max(0, seat.wl_count - 1)
                elif seat.rac_count < rac_capacity:
                    p.status = "RAC"
                    p.coach_number = f"{coach_prefix}1"
                    p.seat_number = f"SUB_{seat.rac_count + 1}"
                    
                    seat.rac_count += 1
                    seat.wl_count = max(0, seat.wl_count - 1)
                else:
                    # No more promotion slots available, break early
                    break

            # 3. Recalculate booking status badges for any booking that was updated
            for b in bookings_list:
                p_statuses = [p.status for p in b.passengers]
                if "WL" in p_statuses:
                    b.status = "WL"
                elif "RAC" in p_statuses:
                    b.status = "RAC"
                else:
                    b.status = "CONFIRMED"

            db.commit()
            print(f"Waitlist promotion executed for {train_number} on {journey_date}.")
        except Exception as e:
            print(f"Error during waitlist promotion: {e}")
            db.rollback()
        finally:
            db.close()
