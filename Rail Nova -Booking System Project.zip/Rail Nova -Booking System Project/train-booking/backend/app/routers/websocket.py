import asyncio
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from sqlalchemy.orm import Session
from datetime import date
from app.database import SessionLocal
from app.services.booking_service import active_ws_connections
from app.services.tatkal_service import active_tatkal_ws_connections, TatkalService
from app.services.train_service import TrainService
from app.models.train import Train

router = APIRouter(tags=["WebSockets"])

@router.websocket("/ws/seats/{train_number}/{journey_date}")
async def ws_seats(websocket: WebSocket, train_number: str, journey_date: str):
    await websocket.accept()
    key = f"{train_number}:{journey_date}"
    
    if key not in active_ws_connections:
        active_ws_connections[key] = []
    active_ws_connections[key].append(websocket)
    
    db = SessionLocal()
    try:
        # On connection, send initial availability
        train = db.query(Train).filter_by(train_number=train_number).first()
        if train:
            j_date = date.fromisoformat(journey_date)
            classes = ["1AC", "2AC", "3AC", "SL", "CC"]
            availabilities = []
            for c_class in classes:
                avail = TrainService.get_class_availability(db, train, j_date, c_class)
                if avail:
                    availabilities.append({
                        "coach_class": c_class,
                        "available_seats": avail.available_seats,
                        "status": avail.status,
                        "fare": avail.fare
                    })
            await websocket.send_json({"type": "initial_availability", "availabilities": availabilities})
            
        # Keep connection alive
        while True:
            # We just wait for incoming messages (e.g. heartbeat or ignore)
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        if key in active_ws_connections and websocket in active_ws_connections[key]:
            active_ws_connections[key].remove(websocket)
    finally:
        db.close()

@router.websocket("/ws/tatkal/{train_number}/{journey_date}/{coach_class}")
async def ws_tatkal(
    websocket: WebSocket,
    train_number: str,
    journey_date: str,
    coach_class: str,
    user_id: str
):
    await websocket.accept()
    key = f"{train_number}:{journey_date}:{coach_class}"
    
    if key not in active_tatkal_ws_connections:
        active_tatkal_ws_connections[key] = []
    active_tatkal_ws_connections[key].append(websocket)
    
    db = SessionLocal()
    try:
        j_date = date.fromisoformat(journey_date)
        while True:
            # Fetch latest queue position status
            status_info = TatkalService.get_status(db, user_id, train_number, j_date, coach_class)
            await websocket.send_json(status_info)
            
            # Query every 5 seconds
            await asyncio.sleep(5)
    except WebSocketDisconnect:
        if key in active_tatkal_ws_connections and websocket in active_tatkal_ws_connections[key]:
            active_tatkal_ws_connections[key].remove(websocket)
    finally:
        db.close()

# Global set of active heartbeat connections for automated shutdown on browser exit
active_heartbeats = set()
shutdown_task = None

async def delayed_shutdown():
    await asyncio.sleep(5) # Allow 5 seconds for page refreshes/navigation
    if len(active_heartbeats) == 0:
        import os
        # Bypass auto-shutdown in cloud/deployment environments
        if os.environ.get("DISABLE_AUTO_SHUTDOWN", "false").lower() == "true" or os.environ.get("PORT") is not None:
            print("Auto-shutdown bypassed: App is running in deployment mode.")
            return

        print("\n====================================================")
        print("💤 NO ACTIVE BROWSER CONNECTIONS DETECTED FOR 5S.")
        print("🚪 SHUTTING DOWN RAIL NOVA BACKEND SERVER GRACEFULLY...")
        print("====================================================\n")
        import signal
        # Send SIGINT to gracefully stop Uvicorn
        os.kill(os.getpid(), signal.SIGINT)

@router.websocket("/ws/heartbeat")
async def ws_heartbeat(websocket: WebSocket):
    global shutdown_task
    await websocket.accept()
    
    # Cancel any pending shutdown task because a browser tab is active
    if shutdown_task and not shutdown_task.done():
        shutdown_task.cancel()
        shutdown_task = None
        
    active_heartbeats.add(websocket)
    try:
        while True:
            # Hold the connection open
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in active_heartbeats:
            active_heartbeats.remove(websocket)
        # If all tabs are closed, schedule delayed shutdown
        if len(active_heartbeats) == 0:
            shutdown_task = asyncio.create_task(delayed_shutdown())
