from .auth import router as auth_router
from .trains import train_router, station_router
from .bookings import router as bookings_router
from .payments import router as payments_router
from .passengers import router as passengers_router
from .websocket import router as websocket_router

__all__ = [
    "auth_router",
    "train_router",
    "station_router",
    "bookings_router",
    "payments_router",
    "passengers_router",
    "websocket_router",
]
