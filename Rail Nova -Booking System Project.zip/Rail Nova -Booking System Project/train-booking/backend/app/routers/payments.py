from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.payment import Payment
from app.schemas.payment import PaymentCreateOrder, PaymentOrderOut, PaymentVerify, PaymentVerifyOut, WalletTopUp
from app.services.payment_service import PaymentService

router = APIRouter(prefix="/api/payments", tags=["Payments"])

@router.post("/create-order", response_model=PaymentOrderOut)
def create_order(
    schema: PaymentCreateOrder,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        return PaymentService.create_mock_order(db, schema.booking_id)
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/verify", response_model=PaymentVerifyOut)
def verify_payment(
    schema: PaymentVerify,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        return PaymentService.verify_mock_payment(db, schema)
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/{booking_id}")
def get_payment_status(
    booking_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    payment = db.query(Payment).filter_by(booking_id=booking_id).order_by(Payment.created_at.desc()).first()
    if not payment:
        raise HTTPException(status_code=404, detail="No payment record found for this booking")
    return {
        "booking_id": booking_id,
        "razorpay_order_id": payment.razorpay_order_id,
        "razorpay_payment_id": payment.razorpay_payment_id,
        "amount": float(payment.amount),
        "status": payment.status,
        "created_at": payment.created_at
    }

@router.get("/ewallet/balance")
def get_ewallet_balance(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        return PaymentService.get_wallet_history(db, current_user.id)
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/ewallet/topup")
def topup_ewallet(
    schema: WalletTopUp,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        return PaymentService.topup_wallet(db, current_user.id, schema.amount)
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/pay-via-wallet")
def pay_via_wallet(
    schema: PaymentCreateOrder,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        return PaymentService.pay_via_wallet(db, current_user.id, schema.booking_id)
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
