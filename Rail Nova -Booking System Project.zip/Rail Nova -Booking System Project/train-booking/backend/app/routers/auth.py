from fastapi import APIRouter, Depends, status, Response
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.schemas.auth import UserRegister, UserLogin, UserProfileUpdate, ChangePassword, UserOut, Token
from app.services.auth_service import AuthService
from app.utils.security import create_access_token

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(schema: UserRegister, db: Session = Depends(get_db)):
    return AuthService.register(db, schema)

@router.post("/login", response_model=Token)
def login(schema: UserLogin, db: Session = Depends(get_db)):
    user = AuthService.authenticate(db, schema.email, schema.password)
    access_token = create_access_token(subject=user.id)
    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/logout")
def logout():
    # Since we are on a simplified stateless JWT + SQLite stack,
    # logout is handled cleanly by the client discarding the token.
    return {"detail": "Successfully logged out."}

@router.get("/me", response_model=UserOut)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user

@router.put("/profile", response_model=UserOut)
def update_profile(
    schema: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return AuthService.update_profile(db, current_user.id, schema)

@router.put("/change-password")
def change_password(
    schema: ChangePassword,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    AuthService.change_password(db, current_user.id, schema)
    return {"detail": "Password successfully updated."}


