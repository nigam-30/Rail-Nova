from fastapi import APIRouter, Depends, status, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.booking import Booking
from app.models.train import Train
from app.schemas.booking import BookingCreate, BookingOut, BookingHistoryOut
from app.services.booking_service import BookingService

router = APIRouter(prefix="/api/bookings", tags=["Bookings"])

@router.post("", response_model=BookingOut, status_code=status.HTTP_201_CREATED)
def create_booking(
    schema: BookingCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    try:
        booking = BookingService.initiate_booking(db, current_user.id, schema)
        return booking
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Booking initiation failed: {str(e)}")

@router.get("", response_model=List[BookingHistoryOut])
def get_booking_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    bookings = db.query(Booking).filter_by(user_id=current_user.id).order_by(Booking.created_at.desc()).all()
    
    # We can dynamically map the train name for convenience
    results = []
    for b in bookings:
        train = db.query(Train).filter_by(train_number=b.train_number).first()
        b.train_name = train.train_name if train else "Unknown Train"
        results.append(b)
        
    return results

@router.get("/{pnr}", response_model=BookingHistoryOut)
def get_booking_by_pnr(
    pnr: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    booking = db.query(Booking).filter_by(pnr=pnr).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking PNR not found")
        
    if booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized to view this booking")
        
    train = db.query(Train).filter_by(train_number=booking.train_number).first()
    booking.train_name = train.train_name if train else "Unknown Train"
    return booking

@router.delete("/{pnr}", response_model=BookingHistoryOut)
def cancel_booking(
    pnr: str,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    booking = BookingService.cancel_booking(db, pnr, current_user.id, background_tasks)
    train = db.query(Train).filter_by(train_number=booking.train_number).first()
    booking.train_name = train.train_name if train else "Unknown Train"
    return booking

from datetime import date
from pydantic import BaseModel

class TatkalJoinSchema(BaseModel):
    train_number: str
    journey_date: date
    coach_class: str

@router.post("/tatkal/join")
def join_tatkal(
    schema: TatkalJoinSchema,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    from app.services.tatkal_service import TatkalService
    return TatkalService.join_queue(db, current_user.id, schema.train_number, schema.journey_date, schema.coach_class)

@router.get("/tatkal/status")
def get_tatkal_status(
    train_number: str,
    journey_date: date,
    coach_class: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    from app.services.tatkal_service import TatkalService
    return TatkalService.get_status(db, current_user.id, train_number, journey_date, coach_class)

@router.put("/tatkal/status")
def update_tatkal_status(
    train_number: str,
    journey_date: date,
    coach_class: str,
    status: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    from app.models.tatkal_queue import TatkalQueue
    entry = db.query(TatkalQueue).filter_by(
        user_id=current_user.id,
        train_number=train_number,
        journey_date=journey_date,
        coach_class=coach_class
    ).order_by(TatkalQueue.joined_at.desc()).first()
    
    if entry:
        entry.status = status
        db.commit()
    return {"status": status}

