from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from datetime import date
from typing import List
from app.database import get_db
from app.dependencies import get_current_user
from app.models.user import User
from app.models.passenger import Passenger
from app.models.booking import Booking
from app.schemas.passenger import PassengerOut, PassengerCreate

router = APIRouter(prefix="/api/passengers", tags=["Passengers"])

@router.get("/{booking_id}", response_model=List[PassengerOut])
def get_passengers(
    booking_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    booking = db.query(Booking).filter_by(id=booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
        
    if booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized to view passengers of this booking")
        
    return booking.passengers

@router.put("/{passenger_id}", response_model=PassengerOut)
def update_passenger(
    passenger_id: str,
    schema: PassengerCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    passenger = db.query(Passenger).filter_by(id=passenger_id).first()
    if not passenger:
        raise HTTPException(status_code=404, detail="Passenger not found")
        
    if passenger.booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized to edit this passenger")
        
    if passenger.booking.journey_date <= date.today():
        raise HTTPException(status_code=400, detail="Cannot update passenger details on or after departure date")
        
    passenger.name = schema.name
    passenger.age = schema.age
    passenger.gender = schema.gender
    passenger.berth_pref = schema.berth_pref
    
    db.commit()
    db.refresh(passenger)
    return passenger
