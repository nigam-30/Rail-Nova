from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from datetime import date
from typing import List, Optional
from app.database import get_db
from app.schemas.train import TrainOut, TrainSearchCardOut, SeatAvailabilityOut, StationOut
from app.services.train_service import TrainService
from app.models.train import Train

train_router = APIRouter(prefix="/api/trains", tags=["Trains"])
station_router = APIRouter(prefix="/api/stations", tags=["Stations"])

@train_router.get("/search", response_model=List[TrainSearchCardOut])
def search_trains(
    from_station: str = Query(..., alias="from"),
    to_station: str = Query(..., alias="to"),
    journey_date: date = Query(..., alias="date"),
    coach_class: Optional[str] = Query(None, alias="class"),
    db: Session = Depends(get_db)
):
    try:
        return TrainService.search_trains(db, from_station, to_station, journey_date, coach_class)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Search failed: {str(e)}")

@train_router.get("/{train_number}", response_model=TrainOut)
def get_train_details(train_number: str, db: Session = Depends(get_db)):
    train = db.query(Train).filter_by(train_number=train_number).first()
    if not train:
        raise HTTPException(status_code=404, detail="Train not found")
    return train

@train_router.get("/{train_number}/availability", response_model=SeatAvailabilityOut)
def get_seat_availability(
    train_number: str,
    coach_class: str = Query(..., alias="class"),
    journey_date: date = Query(..., alias="date"),
    db: Session = Depends(get_db)
):
    train = db.query(Train).filter_by(train_number=train_number).first()
    if not train:
        raise HTTPException(status_code=404, detail="Train not found")
        
    avail = TrainService.get_class_availability(db, train, journey_date, coach_class)
    if not avail:
        raise HTTPException(status_code=400, detail="Coach class not supported on this train")
        
    return SeatAvailabilityOut(
        train_number=train_number,
        journey_date=journey_date,
        coach_class=coach_class,
        total_seats=200 if coach_class != "SL" else 500, # dynamic placeholder
        available_seats=avail.available_seats,
        rac_count=avail.rac_count,
        wl_count=avail.wl_count,
        fare=avail.fare,
        status=avail.status
    )

@station_router.get("/search", response_model=List[StationOut])
def search_stations(q: str = "", db: Session = Depends(get_db)):
    return TrainService.search_stations(db, q)
