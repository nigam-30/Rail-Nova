from pydantic import BaseModel, Field
from typing import Optional

class PassengerBase(BaseModel):
    name: str = Field(..., min_length=1)
    age: int = Field(..., ge=1, le=120)
    gender: str
    berth_pref: Optional[str] = "No Preference" # Lower/Middle/Upper/Side Lower/Side Upper/No Preference

class PassengerCreate(PassengerBase):
    pass

class PassengerOut(PassengerBase):
    id: str
    seat_number: Optional[str] = None
    coach_number: Optional[str] = None
    berth_type: Optional[str] = None
    status: str

    class Config:
        from_attributes = True
