from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import date, datetime
from .passenger import PassengerCreate, PassengerOut
from .train import TrainOut

class BookingCreate(BaseModel):
    train_number: str
    journey_date: date
    coach_class: str # SL, 3AC, 2AC, 1AC, CC
    is_tatkal: bool = False
    passengers: List[PassengerCreate] = Field(..., min_items=1, max_items=6)
    from_station: Optional[str] = None
    to_station: Optional[str] = None

class BookingOut(BaseModel):
    id: str
    pnr: str
    user_id: str
    train_number: str
    journey_date: date
    from_station: str
    to_station: str
    coach_class: str
    is_tatkal: bool
    total_fare: float
    status: str # PENDING, CONFIRMED, RAC, WL, CANCELLED
    wl_number: Optional[int] = None
    rac_number: Optional[int] = None
    payment_status: str # UNPAID, PAID, REFUNDED
    created_at: datetime
    passengers: List[PassengerOut]

    class Config:
        from_attributes = True

class BookingHistoryOut(BaseModel):
    id: str
    pnr: str
    train_number: str
    train_name: str
    journey_date: date
    from_station: str
    to_station: str
    coach_class: str
    is_tatkal: bool
    total_fare: float
    status: str
    payment_status: str
    created_at: datetime
    passengers: List[PassengerOut]

    class Config:
        from_attributes = True
