from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import date

class UserRegister(BaseModel):
    email: EmailStr
    mobile: str = Field(..., pattern=r"^[6-9]\d{9}$", description="10-digit Indian mobile starting with 6, 7, 8, or 9")
    password: str = Field(..., min_length=8, description="Password must be at least 8 characters")
    full_name: str
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None
    id_type: Optional[str] = None # Aadhaar / PAN / Passport
    id_number: Optional[str] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    mobile: Optional[str] = Field(None, pattern=r"^[6-9]\d{9}$")
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None
    id_type: Optional[str] = None
    id_number: Optional[str] = None

class ChangePassword(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=8)

class UserOut(BaseModel):
    id: str
    email: str
    mobile: str
    full_name: str
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None
    id_type: Optional[str] = None
    id_number: Optional[str] = None
    is_verified: bool
    ewallet_balance: Optional[float] = 0.0

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
