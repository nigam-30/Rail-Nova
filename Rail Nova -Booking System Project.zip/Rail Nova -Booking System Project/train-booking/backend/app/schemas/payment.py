from pydantic import BaseModel
from typing import Optional

class PaymentCreateOrder(BaseModel):
    booking_id: str

class PaymentOrderOut(BaseModel):
    order_id: str
    amount: float
    currency: str = "INR"

class PaymentVerify(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str

class PaymentVerifyOut(BaseModel):
    status: str
    payment_id: str

class WalletTopUp(BaseModel):
    amount: float
