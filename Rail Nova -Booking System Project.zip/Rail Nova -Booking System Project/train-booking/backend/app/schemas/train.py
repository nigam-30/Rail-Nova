from pydantic import BaseModel
from typing import Optional, List
from datetime import date

class StationOut(BaseModel):
    station_code: str
    station_name: str
    zone: Optional[str] = None
    state: Optional[str] = None
    address: Optional[str] = None
    longitude: Optional[float] = None
    latitude: Optional[float] = None

    class Config:
        from_attributes = True

class TrainOut(BaseModel):
    train_number: str
    train_name: str
    from_station_code: Optional[str] = None
    from_station_name: Optional[str] = None
    to_station_code: Optional[str] = None
    to_station_name: Optional[str] = None
    departure: Optional[str] = None
    arrival: Optional[str] = None
    duration_h: Optional[int] = None
    duration_m: Optional[int] = None
    distance_km: Optional[float] = None
    train_type: Optional[str] = None
    zone: Optional[str] = None
    has_1ac: bool
    has_2ac: bool
    has_3ac: bool
    has_sleeper: bool
    has_chair_car: bool
    has_first_class: bool

    class Config:
        from_attributes = True

class ClassAvailability(BaseModel):
    coach_class: str
    available_seats: int
    rac_count: int
    wl_count: int
    fare: float
    status: str # AVAILABLE / RAC / WL / FULL

class TrainSearchCardOut(BaseModel):
    train: TrainOut
    availabilities: List[ClassAvailability]

class SeatAvailabilityOut(BaseModel):
    train_number: str
    journey_date: date
    coach_class: str
    total_seats: int
    available_seats: int
    rac_count: int
    wl_count: int
    fare: float
    status: str
