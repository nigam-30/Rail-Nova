import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.config import settings
from app.database import engine, Base, SessionLocal
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.logging import LoggingMiddleware
from app.routers import (
    auth_router,
    train_router,
    station_router,
    bookings_router,
    payments_router,
    passengers_router,
    websocket_router,
)
from app.models.seat_lock import SeatLock
from app.models.booking import Booking
from app.models.tatkal_queue import TatkalQueue
from app.services.tatkal_service import broadcast_tatkal_updates

async def expired_lock_cleanup_loop():
    """Background loop that runs every 60s to cancel unpaid bookings past 10-min locks."""
    while True:
        await asyncio.sleep(60)
        db = SessionLocal()
        try:
            now = datetime.now()
            # 1. Fetch expired locks
            expired_locks = db.query(SeatLock).filter(SeatLock.expires_at < now).all()
            
            for lock in expired_locks:
                # Cancel the associated booking
                booking = db.query(Booking).filter_by(id=lock.id, status="PENDING").first()
                if booking:
                    booking.status = "CANCELLED"
                    booking.payment_status = "EXPIRED"
                    
                    # Release any passenger status
                    for p in booking.passengers:
                        p.status = "CANCELLED"
                
                # Delete the lock row
                db.delete(lock)
                
            db.commit()
            if expired_locks:
                print(f"Cleaned up {len(expired_locks)} expired seat locks and cancelled their bookings.")
        except Exception as e:
            print(f"Error in seat lock cleanup background task: {e}")
            db.rollback()
        finally:
            db.close()

async def tatkal_window_cleanup_loop():
    """Background loop that runs every 60s to expire active tatkal windows and promote next users."""
    while True:
        await asyncio.sleep(60)
        db = SessionLocal()
        try:
            now = datetime.now()
            # 1. Query active tatkal entries that have expired
            expired_active = db.query(TatkalQueue).filter(
                TatkalQueue.status == "ACTIVE",
                TatkalQueue.window_end < now
            ).all()

            for entry in expired_active:
                entry.status = "EXPIRED"
                db.commit()
                
                # Broadcast status update
                await broadcast_tatkal_updates(entry.train_number, str(entry.journey_date), entry.coach_class)
                
                # Activate the next user in the queue
                next_in_queue = db.query(TatkalQueue).filter(
                    TatkalQueue.train_number == entry.train_number,
                    TatkalQueue.journey_date == entry.journey_date,
                    TatkalQueue.coach_class == entry.coach_class,
                    TatkalQueue.status == "WAITING"
                ).order_by(TatkalQueue.joined_at.asc()).first()
                
                if next_in_queue:
                    next_in_queue.status = "ACTIVE"
                    next_in_queue.window_start = now
                    next_in_queue.window_end = now + timedelta(minutes=10)
                    db.commit()
                    
                    # Broadcast status update for the newly activated user
                    await broadcast_tatkal_updates(entry.train_number, str(entry.journey_date), entry.coach_class)
            
        except Exception as e:
            print(f"Error in tatkal window cleanup background task: {e}")
            db.rollback()
        finally:
            db.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup tasks
    print("Starting background cleanup tasks...")
    
    # Run dynamic DB migrations for eWallet columns & tables
    db = SessionLocal()
    try:
        from sqlalchemy import text
        res = db.execute(text("PRAGMA table_info(users)")).fetchall()
        columns = [r[1] for r in res]
        if "ewallet_balance" not in columns:
            print("Migration: Adding ewallet_balance to users table...")
            db.execute(text("ALTER TABLE users ADD COLUMN ewallet_balance FLOAT DEFAULT 0.0"))
            db.commit()

        print("Migration: Ensuring wallet_transactions table exists...")
        Base.metadata.create_all(bind=engine)
        print("Migration complete!")
    except Exception as e:
        print(f"Error executing DB startup migrations: {e}")
        db.rollback()
    finally:
        db.close()

    asyncio.create_task(expired_lock_cleanup_loop())
    asyncio.create_task(tatkal_window_cleanup_loop())
    yield
    # Shutdown tasks (if any)
    print("Stopping application...")

app = FastAPI(
    title="Rail Nova-Style Train Booking API",
    description="Lightweight High-Performance Train Booking API built with FastAPI, SQLite, and WebSockets.",
    version="1.0.0",
    lifespan=lifespan
)

# Middlewares
app.add_middleware(LoggingMiddleware)
app.add_middleware(RateLimitMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.staticfiles import StaticFiles

# Mount Routers
app.include_router(auth_router)
app.include_router(train_router)
app.include_router(station_router)
app.include_router(bookings_router)
app.include_router(payments_router)
app.include_router(passengers_router)
app.include_router(websocket_router)

# Mount frontend static files
import os
from pathlib import Path

base_dir = Path(__file__).resolve().parent
possible_paths = [
    base_dir / ".." / ".." / ".." / "frontend", # 3 levels up: sibling of train-booking
    base_dir / ".." / ".." / "frontend",      # 2 levels up: inside train-booking
    base_dir / ".." / "frontend",            # 1 level up: inside backend
    Path(os.getcwd()) / ".." / ".." / "frontend",
    Path(os.getcwd()) / ".." / "frontend",
    Path(os.getcwd()) / "frontend",
]

frontend_dir = None
for p in possible_paths:
    if p.exists() and p.is_dir():
        frontend_dir = str(p.resolve())
        break

if not frontend_dir:
    frontend_dir = "../frontend"

print(f"Static files mounted from: {frontend_dir}")
app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")
