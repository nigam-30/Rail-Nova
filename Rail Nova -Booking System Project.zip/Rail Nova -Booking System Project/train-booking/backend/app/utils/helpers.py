import random
from datetime import datetime
from sqlalchemy.orm import Session

def generate_pnr() -> str:
    now = datetime.now()
    year_2d = f"{now.year % 100:02d}"
    doy_3d = f"{now.timetuple().tm_yday:03d}"
    random_5d = f"{random.randint(10000, 99999):05d}"
    return f"{year_2d}{doy_3d}{random_5d}"

def generate_unique_pnr(db: Session) -> str:
    from app.models.booking import Booking
    for _ in range(10): # retry up to 10 times in case of collision
        pnr = generate_pnr()
        exists = db.query(Booking).filter_by(pnr=pnr).first()
        if not exists:
            return pnr
    raise RuntimeError("Could not generate a unique PNR. Please retry.")
