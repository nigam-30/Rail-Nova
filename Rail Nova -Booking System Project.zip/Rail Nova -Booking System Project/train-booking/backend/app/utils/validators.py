import re
from datetime import date, timedelta
from typing import Optional

def validate_mobile(mobile: str) -> bool:
    return bool(re.match(r"^[6-9]\d{9}$", mobile))

def validate_pan(pan: str) -> bool:
    return bool(re.match(r"^[A-Z]{5}[0-9]{4}[A-Z]{1}$", pan))

def validate_aadhaar(aadhaar: str) -> bool:
    return bool(re.match(r"^\d{12}$", aadhaar))

def validate_passenger_age(age: int) -> bool:
    return 1 <= age <= 120

def validate_journey_date(journey_date: date) -> bool:
    today = date.today()
    max_date = today + timedelta(days=90)
    return today <= journey_date <= max_date

def validate_passenger_count(count: int) -> bool:
    return 1 <= count <= 6
