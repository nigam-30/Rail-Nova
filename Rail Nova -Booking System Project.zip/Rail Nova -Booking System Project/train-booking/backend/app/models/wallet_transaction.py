import uuid
from sqlalchemy import Column, String, Float, DateTime, func, ForeignKey
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class WalletTransaction(Base):
    __tablename__ = "wallet_transactions"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    amount = Column(Float, nullable=False)
    type = Column(String, nullable=False) # DEPOSIT, PAYMENT, REFUND
    description = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
