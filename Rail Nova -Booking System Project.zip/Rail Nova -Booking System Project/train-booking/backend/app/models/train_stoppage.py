from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class TrainStoppage(Base):
    __tablename__ = "train_stoppages"

    id = Column(Integer, primary_key=True, index=True)
    train_number = Column(String, ForeignKey("trains.train_number"), index=True, nullable=False)
    station_code = Column(String, ForeignKey("stations.station_code"), index=True, nullable=False)
    station_name = Column(String, nullable=False)
    arrival = Column(String, nullable=True) # HH:MM:SS (None for first stop)
    departure = Column(String, nullable=True) # HH:MM:SS (None for last stop)
    day = Column(Integer, default=1, nullable=False)
    stop_number = Column(Integer, index=True, nullable=False)

    train = relationship("Train", backref="stoppages")
    station = relationship("Station", backref="stoppages")
