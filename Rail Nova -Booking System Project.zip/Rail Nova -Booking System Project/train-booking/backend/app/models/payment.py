import uuid
from sqlalchemy import Column, String, Numeric, ForeignKey, DateTime, func
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class Payment(Base):
    __tablename__ = "payments"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    booking_id = Column(String, ForeignKey("bookings.id"), nullable=False)
    razorpay_order_id = Column(String, unique=True, nullable=False, index=True)
    razorpay_payment_id = Column(String, nullable=True)
    amount = Column(Numeric(10, 2), nullable=False)
    currency = Column(String, default="INR")
    status = Column(String, default="CREATED") # CREATED, PAID, FAILED, REFUNDED
    created_at = Column(DateTime(timezone=True), server_default=func.now())
