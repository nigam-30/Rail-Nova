from sqlalchemy import Column, String, Float
from sqlalchemy.orm import relationship
from app.database import Base

class Station(Base):
    __tablename__ = "stations"

    station_code = Column(String, primary_key=True, index=True) # e.g. 'BVI', 'NDLS'
    station_name = Column(String, nullable=False, index=True)
    zone = Column(String, nullable=True)
    state = Column(String, nullable=True)
    address = Column(String, nullable=True)
    longitude = Column(Float, nullable=True)
    latitude = Column(Float, nullable=True)
