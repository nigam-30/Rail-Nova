import uuid
from sqlalchemy import Column, String, Date, Integer, ForeignKey, UniqueConstraint
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class Seat(Base):
    __tablename__ = "seats"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    train_number = Column(String, ForeignKey("trains.train_number"), nullable=False)
    journey_date = Column(Date, nullable=False, index=True)
    coach_class = Column(String, nullable=False) # SL, 3AC, 2AC, 1AC, CC
    total_seats = Column(Integer, nullable=False)
    confirmed = Column(Integer, default=0)
    rac_count = Column(Integer, default=0)
    wl_count = Column(Integer, default=0)
    locked_seats = Column(Integer, default=0)

    __table_args__ = (
        UniqueConstraint("train_number", "journey_date", "coach_class", name="uq_train_date_class"),
    )
