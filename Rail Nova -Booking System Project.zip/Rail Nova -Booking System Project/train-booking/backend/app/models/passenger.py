import uuid
from sqlalchemy import Column, String, Integer, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class Passenger(Base):
    __tablename__ = "passengers"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    booking_id = Column(String, ForeignKey("bookings.id", ondelete="CASCADE"), nullable=False)
    name = Column(String, nullable=False)
    age = Column(Integer, nullable=False)
    gender = Column(String, nullable=False)
    berth_pref = Column(String, nullable=True) # Lower, Middle, Upper, Side Lower, Side Upper, No Preference
    seat_number = Column(String, nullable=True) # assigned after confirmation
    coach_number = Column(String, nullable=True)
    status = Column(String, nullable=False) # CNF, RAC, WL

    booking = relationship("Booking", back_populates="passengers")

    @property
    def berth_type(self) -> str:
        if not self.seat_number:
            return ""
            
        # Handle RAC passengers
        if "SUB_" in str(self.seat_number):
            return "SL"  # Side Lower
            
        # Attempt to parse seat number as integer
        try:
            seat_num = int(self.seat_number)
        except ValueError:
            return ""
            
        c_class = "SL"
        if self.booking:
            c_class = self.booking.coach_class.strip().upper()
            
        # 1. Seating Classes (CC, 2S, EC, EA, VS)
        if c_class in {"CC", "2S", "EC", "EA", "VS"}:
            rem = seat_num % 6
            if rem in (1, 0):
                return "WS"  # Window Seat
            elif rem in (2, 5):
                return "MS"  # Middle Seat
            else:
                return "AS"  # Aisle Seat
                
        # 2. AC First Class (1A, 1AC, FC)
        elif c_class in {"1A", "1AC", "FC"}:
            rem = seat_num % 4
            if rem in (1, 3):
                return "LB"  # Lower Berth
            else:
                return "UB"  # Upper Berth
                
        # 3. AC 2-Tier (2A, 2AC)
        elif c_class in {"2A", "2AC"}:
            rem = seat_num % 6
            if rem in (1, 3):
                return "LB"  # Lower Berth
            elif rem in (2, 4):
                return "UB"  # Upper Berth
            elif rem == 5:
                return "SL"  # Side Lower
            else:
                return "SU"  # Side Upper
                
        # 4. Sleeper & AC 3-Tier (SL, 3A, 3AC, 3E)
        else:
            rem = seat_num % 8
            if rem in (1, 4):
                return "LB"  # Lower Berth
            elif rem in (2, 5):
                return "MB"  # Middle Berth
            elif rem in (3, 6):
                return "UB"  # Upper Berth
            elif rem == 7:
                return "SL"  # Side Lower
            else:
                return "SU"  # Side Upper
