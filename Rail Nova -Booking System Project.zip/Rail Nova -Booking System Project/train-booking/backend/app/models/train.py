from sqlalchemy import Column, String, Integer, Float, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.database import Base

class Train(Base):
    __tablename__ = "trains"

    train_number = Column(String, primary_key=True, index=True) # e.g. '12951'
    train_name = Column(String, nullable=False)
    from_station_code = Column(String, ForeignKey("stations.station_code"), nullable=True)
    from_station_name = Column(String, nullable=True)
    to_station_code = Column(String, ForeignKey("stations.station_code"), nullable=True)
    to_station_name = Column(String, nullable=True)
    departure = Column(String, nullable=True) # HH:MM:SS
    arrival = Column(String, nullable=True) # HH:MM:SS
    duration_h = Column(Integer, nullable=True)
    duration_m = Column(Integer, nullable=True)
    distance_km = Column(Float, nullable=True)
    train_type = Column(String, nullable=True) # Exp, SF, Raj, Shtb...
    zone = Column(String, nullable=True)
    return_train = Column(String, nullable=True)
    has_1ac = Column(Boolean, default=False)
    has_2ac = Column(Boolean, default=False)
    has_3ac = Column(Boolean, default=False)
    has_sleeper = Column(Boolean, default=False)
    has_chair_car = Column(Boolean, default=False)
    has_first_class = Column(Boolean, default=False)

    from_station = relationship("Station", foreign_keys=[from_station_code])
    to_station = relationship("Station", foreign_keys=[to_station_code])
