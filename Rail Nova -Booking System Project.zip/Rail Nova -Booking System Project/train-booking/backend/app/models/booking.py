import uuid
from sqlalchemy import Column, String, Date, Boolean, Numeric, Integer, ForeignKey, DateTime, func
from sqlalchemy.orm import relationship
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class Booking(Base):
    __tablename__ = "bookings"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    pnr = Column(String, unique=True, nullable=False, index=True) # 10-digit PNR
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    train_number = Column(String, ForeignKey("trains.train_number"), nullable=False)
    journey_date = Column(Date, nullable=False, index=True)
    from_station = Column(String, ForeignKey("stations.station_code"), nullable=False)
    to_station = Column(String, ForeignKey("stations.station_code"), nullable=False)
    coach_class = Column(String, nullable=False) # SL, 3AC, 2AC, 1AC, CC
    is_tatkal = Column(Boolean, default=False)
    total_fare = Column(Numeric(10, 2), nullable=False)
    status = Column(String, default="PENDING") # PENDING, CONFIRMED, RAC, WL, CANCELLED
    wl_number = Column(Integer, nullable=True) # null if CNF or RAC
    rac_number = Column(Integer, nullable=True) # null if CNF or WL
    payment_status = Column(String, default="UNPAID") # UNPAID, PAID, REFUNDED
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", backref="bookings")
    train = relationship("Train", backref="bookings")
    passengers = relationship("Passenger", back_populates="booking", cascade="all, delete-orphan")
