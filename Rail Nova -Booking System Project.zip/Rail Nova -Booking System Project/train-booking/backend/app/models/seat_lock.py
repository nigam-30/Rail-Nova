import uuid
from sqlalchemy import Column, String, ForeignKey, DateTime
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class SeatLock(Base):
    __tablename__ = "seat_locks"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    train_number = Column(String, ForeignKey("trains.train_number"), nullable=False)
    journey_date = Column(String, nullable=False) # e.g. "2026-05-30"
    coach_class = Column(String, nullable=False) # SL, 3AC, 2AC, 1AC, CC
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    expires_at = Column(DateTime, nullable=False)
