import uuid
from sqlalchemy import Column, String, Date, Boolean, DateTime, Float, func
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    mobile = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    date_of_birth = Column(Date, nullable=True)
    gender = Column(String, nullable=True)
    id_type = Column(String, nullable=True) # Aadhaar / PAN / Passport
    id_number = Column(String, nullable=True)
    is_verified = Column(Boolean, default=False)
    ewallet_balance = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
