import uuid
from sqlalchemy import Column, String, Date, DateTime, Integer, ForeignKey, func
from app.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class TatkalQueue(Base):
    __tablename__ = "tatkal_queue"

    id = Column(String, primary_key=True, default=generate_uuid, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    train_number = Column(String, ForeignKey("trains.train_number"), nullable=False)
    journey_date = Column(Date, nullable=False, index=True)
    coach_class = Column(String, nullable=False) # SL, 3AC, 2AC, 1AC, CC
    joined_at = Column(DateTime(timezone=True), server_default=func.now())
    position = Column(Integer, nullable=False)
    window_start = Column(DateTime, nullable=True)
    window_end = Column(DateTime, nullable=True)
    status = Column(String, default="WAITING") # WAITING, ACTIVE, EXPIRED, BOOKED
