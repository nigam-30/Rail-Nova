@echo off
title IRCTC NextGen App Launcher
echo ========================================================
echo Installing Python Dependencies...
echo ========================================================
cd train-booking/backend
pip install -r requirements.txt
echo.
echo ========================================================
echo Initializing Database & Seeding Stations and Trains...
echo ========================================================
python seed.py
echo.
echo ========================================================
echo Launching App in Default Browser...
echo ========================================================
start http://localhost:8000
echo.
echo ========================================================
echo Starting FastAPI Uvicorn Server on port 8000...
echo ========================================================
python run.py
pause
