// ==========================================
// Rail Nova — Premium Train Booking Core JS
// ==========================================

// Global Application State
const state = {
  token: localStorage.getItem('token') || null,
  user: null,
  stations: [],
  searchParams: {
    from: '',
    to: '',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0], // tomorrow
    coachClass: '',
    isTatkal: false
  },
  searchResults: [],
  selectedTrain: null,
  selectedClass: null,
  activeBooking: null,
  tatkalQueue: null,
  bookingHistory: [],
  pnrSearchResult: null,
  wsSeatConn: null,
  wsTatkalConn: null,
  activeView: 'home',
  seatSelection: [] // Selected seat numbers for booking passengers
};

// ==========================================
// API Helpers
// ==========================================
const BASE_URL = window.location.origin;

async function apiRequest(endpoint, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (state.token) {
    headers['Authorization'] = `Bearer ${state.token}`;
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers
  });

  if (response.status === 401) {
    // Session expired
    logout();
    throw new Error('Session expired. Please login again.');
  }

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.detail || 'Something went wrong.');
  }
  return data;
}

function setCurrentUser(rawUser) {
  if (!rawUser) {
    state.user = null;
    return;
  }
  state.user = {
    ...rawUser,
    name: rawUser.full_name || rawUser.name,
    aadhaar: rawUser.id_type === 'Aadhaar' ? rawUser.id_number : (rawUser.aadhaar || null),
    pan: rawUser.id_type === 'PAN' ? rawUser.id_number : (rawUser.pan || null)
  };
}

// Check Authentication Status
async function checkAuth() {
  if (!state.token) return false;
  try {
    const rawUser = await apiRequest('/api/auth/me');
    setCurrentUser(rawUser);
    return true;
  } catch (err) {
    logout();
    return false;
  }
}

function logout() {
  state.token = null;
  setCurrentUser(null);
  localStorage.removeItem('token');
  closeWebSockets();
  navigateTo('home');
  renderNavbar();
}

function closeWebSockets() {
  if (state.wsSeatConn) {
    state.wsSeatConn.close();
    state.wsSeatConn = null;
  }
  if (state.wsTatkalConn) {
    state.wsTatkalConn.close();
    state.wsTatkalConn = null;
  }
}

// ==========================================
// Router and Navigation
// ==========================================
const views = {
  home: renderHome,
  login: renderLogin,
  register: renderRegister,
  results: renderResults,
  booking: renderBooking,
  'tatkal-queue': renderTatkalQueue,
  payment: renderPayment,
  history: renderHistory,
  profile: renderProfile
};

function navigateTo(viewName) {
  state.activeView = viewName;
  window.location.hash = `#/${viewName}`;
  closeWebSockets();
  views[viewName]();
  renderNavbar();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleHashChange() {
  const hash = window.location.hash || '#/home';
  const viewName = hash.replace('#/', '');
  if (views[viewName]) {
    state.activeView = viewName;
    views[viewName]();
    renderNavbar();
  } else {
    navigateTo('home');
  }
}

window.addEventListener('hashchange', handleHashChange);

// ==========================================
// Common Dynamic Components
// ==========================================
function renderNavbar() {
  const navContainer = document.getElementById('navbar-container');
  if (!navContainer) return;

  const authLinks = state.user
    ? `
      <div class="flex items-center gap-6">
        <button onclick="navigateTo('history')" class="text-sm font-semibold text-slate-600 hover:text-primary transition">Bookings</button>
        <button onclick="navigateTo('profile')" class="text-sm font-semibold text-slate-600 hover:text-primary transition">Profile</button>
        <div class="h-6 w-[1px] bg-slate-200"></div>
        <div class="flex items-center gap-2">
          <div class="h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm">
            ${state.user.name.charAt(0).toUpperCase()}
          </div>
          <span class="text-sm font-semibold text-slate-700">${state.user.name.split(' ')[0]}</span>
        </div>
        <button onclick="logout()" class="glow-btn px-4 py-1.5 rounded-lg border border-slate-200 text-sm font-semibold hover:bg-slate-50 transition">Logout</button>
      </div>
    `
    : `
      <div class="flex items-center gap-4">
        <button onclick="navigateTo('login')" class="text-sm font-semibold text-slate-600 hover:text-primary transition">Sign In</button>
        <button onclick="navigateTo('register')" class="glow-btn bg-primary text-white px-5 py-2 rounded-xl text-sm font-semibold shadow-md transition">Register</button>
      </div>
    `;

  navContainer.innerHTML = `
    <nav class="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-100 px-6 py-4 shadow-sm">
      <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div onclick="navigateTo('home')" class="flex items-center gap-3 cursor-pointer select-none">
          <span class="text-3xl">🚂</span>
          <div>
            <h1 class="text-xl font-bold tracking-tight text-primary font-serif">Rail Nova</h1>
            <p class="text-[10px] text-slate-400 font-semibold tracking-widest uppercase">Premium Booking Portal</p>
          </div>
        </div>
        ${authLinks}
      </div>
    </nav>
  `;
}

function renderFooter() {
  const appContainer = document.getElementById('app');
  let footer = document.getElementById('main-footer');
  if (!footer) {
    footer = document.createElement('footer');
    footer.id = 'main-footer';
    footer.className = 'bg-slate-900 text-slate-400 py-12 px-6 mt-20 border-t border-slate-800 print:hidden';
    appContainer.after(footer);
  }
  footer.innerHTML = `
    <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
      <div>
        <h3 class="text-white font-serif font-bold text-lg mb-4">🚂 Rail Nova</h3>
        <p class="text-sm">State-of-the-art train ticket reservation system simulating Tatkal locking, waitlists, and instant bookings.</p>
      </div>
      <div>
        <h4 class="text-white font-bold text-sm mb-4 uppercase tracking-wider">Features</h4>
        <ul class="space-y-2 text-sm">
          <li>Real-time Seat Locking</li>
          <li>Virtual Tatkal Waitlist Queue</li>
          <li>Automatic WL/RAC Upgrades</li>
          <li>Interactive Seat blueprints</li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-bold text-sm mb-4 uppercase tracking-wider">Safety & Privacy</h4>
        <ul class="space-y-2 text-sm">
          <li>Aadhaar Card Verification</li>
          <li>PAN Card Verification</li>
          <li>Rate Limiting Guards</li>
          <li>Secure Sessions</li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-bold text-sm mb-4 uppercase tracking-wider">Simulated Portal</h4>
        <p class="text-sm">This is a sandbox deployment featuring mock payments and high-speed SQLite operations.</p>
      </div>
    </div>
    <div class="max-w-7xl mx-auto border-t border-slate-800 mt-8 pt-8 text-center text-xs">
      <p>&copy; 2026 Rail Nova System. Powered by FastAPI and Vanilla Javascript.</p>
    </div>
  `;
}

function showAlert(message, type = 'error') {
  const toast = document.createElement('div');
  toast.className = `fixed bottom-6 right-6 z-50 flex items-center gap-3 px-6 py-4 rounded-xl shadow-2xl transition duration-300 transform translate-y-10 opacity-0 print:hidden ${
    type === 'success' ? 'bg-success text-white' : 'bg-red-600 text-white'
  }`;
  toast.innerHTML = `
    <span class="text-xl">${type === 'success' ? '✓' : '⚠️'}</span>
    <p class="text-sm font-semibold">${message}</p>
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.classList.remove('translate-y-10', 'opacity-0');
  }, 10);
  setTimeout(() => {
    toast.classList.add('translate-y-10', 'opacity-0');
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ==========================================
// VIEW: Home Page (Search Panel)
// ==========================================
function renderHome() {
  const container = document.getElementById('app');
  container.innerHTML = `
    <div class="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
      <!-- Left Branding Pitch -->
      <div class="lg:col-span-5 space-y-6">
        <span class="bg-accent/10 text-accent font-semibold px-3 py-1 rounded-full text-xs uppercase tracking-wider">Fast & Premium Tickets</span>
        <h1 class="text-4xl lg:text-5xl font-extrabold text-primary font-serif leading-tight">
          Next-Generation <br/>Train Ticket Booking
        </h1>
        <p class="text-slate-600 leading-relaxed">
          Experience zero latency bookings, real-time interactive seat layouts, Tatkal queue waitrooms, and automatic waitlist priority promotions. No queues, no fuss.
        </p>
        <div class="flex gap-4">
          <div class="flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-100">
            <span class="text-xl">⚡</span>
            <div class="text-left">
              <h4 class="text-xs text-slate-400 font-semibold uppercase">Tatkal Waitroom</h4>
              <p class="text-sm font-bold text-slate-800">WebSocket Live</p>
            </div>
          </div>
          <div class="flex items-center gap-2 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-100">
            <span class="text-xl">🎟️</span>
            <div class="text-left">
              <h4 class="text-xs text-slate-400 font-semibold uppercase">Auto Promotions</h4>
              <p class="text-sm font-bold text-slate-800">WL & RAC Upgrades</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Search Form Panel -->
      <div class="lg:col-span-7">
        <div class="glass-panel rounded-2xl p-8 shadow-xl border border-white">
          <h2 class="text-2xl font-serif font-bold text-slate-800 mb-6">Book Your Train Journey</h2>
          
          <form id="search-form" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <!-- From Station -->
              <div class="relative">
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">From Station</label>
                <input 
                  type="text" 
                  id="search-from" 
                  placeholder="Type origin station (e.g. NDLS)" 
                  value="${state.searchParams.from}"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                  required
                />
                <div id="from-suggestions" class="absolute left-0 right-0 mt-1 bg-white border border-slate-100 rounded-xl shadow-lg z-20 hidden"></div>
              </div>

              <!-- To Station -->
              <div class="relative">
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">To Station</label>
                <input 
                  type="text" 
                  id="search-to" 
                  placeholder="Type destination station (e.g. HWH)" 
                  value="${state.searchParams.to}"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                  required
                />
                <div id="to-suggestions" class="absolute left-0 right-0 mt-1 bg-white border border-slate-100 rounded-xl shadow-lg z-20 hidden"></div>
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
              <!-- Journey Date -->
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Date of Journey</label>
                <input 
                  type="date" 
                  id="search-date" 
                  value="${state.searchParams.date}"
                  min="${new Date().toISOString().split('T')[0]}"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                  required
                />
              </div>

              <!-- Coach Class -->
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Class</label>
                <select 
                  id="search-class"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition bg-white"
                >
                  <option value="">💼 All Classes</option>
                  <option value="1A" ${state.searchParams.coachClass === '1A' ? 'selected' : ''}>First AC (1A)</option>
                  <option value="2A" ${state.searchParams.coachClass === '2A' ? 'selected' : ''}>AC 2 Tier (2A)</option>
                  <option value="3A" ${state.searchParams.coachClass === '3A' ? 'selected' : ''}>AC 3 Tier (3A)</option>
                  <option value="3E" ${state.searchParams.coachClass === '3E' ? 'selected' : ''}>AC 3 Economy (3E)</option>
                  <option value="EA" ${state.searchParams.coachClass === 'EA' ? 'selected' : ''}>Executive Anubhuti (EA)</option>
                  <option value="EC" ${state.searchParams.coachClass === 'EC' ? 'selected' : ''}>Executive Chair Car (EC)</option>
                  <option value="CC" ${state.searchParams.coachClass === 'CC' ? 'selected' : ''}>AC Chair Car (CC)</option>
                  <option value="FC" ${state.searchParams.coachClass === 'FC' ? 'selected' : ''}>First Class (FC)</option>
                  <option value="SL" ${state.searchParams.coachClass === 'SL' ? 'selected' : ''}>Sleeper Class (SL)</option>
                  <option value="2S" ${state.searchParams.coachClass === '2S' ? 'selected' : ''}>Second Seating (2S)</option>
                  <option value="VS" ${state.searchParams.coachClass === 'VS' ? 'selected' : ''}>Vistadome (VS / EV)</option>
                </select>
              </div>

              <!-- Booking Quota Dropdown -->
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Quota</label>
                <select 
                  id="search-quota"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition bg-white"
                >
                  <option value="GENERAL" ${!state.searchParams.isTatkal ? 'selected' : ''}>GENERAL</option>
                  <option value="LADIES">LADIES</option>
                  <option value="LOWER_BERTH">LOWER BERTH/SR.CITIZEN</option>
                  <option value="DISABILITY">PERSON WITH DISABILITY</option>
                  <option value="DUTY_PASS">DUTY PASS</option>
                  <option value="TATKAL" ${state.searchParams.isTatkal ? 'selected' : ''}>TATKAL</option>
                  <option value="PREMIUM_TATKAL">PREMIUM TATKAL</option>
                </select>
              </div>
            </div>

            <!-- Search Action Button -->
            <button 
              type="submit" 
              class="glow-btn w-full bg-primary hover:bg-primary-light text-white py-4 rounded-xl font-bold text-md shadow-lg transition duration-200 uppercase tracking-wider"
            >
              Search Trains
            </button>
          </form>
        </div>
      </div>
    </div>
  `;

  // Autocomplete bindings
  setupStationAutocomplete('search-from', 'from-suggestions');
  setupStationAutocomplete('search-to', 'to-suggestions');

  // Submit Handler
  document.getElementById('search-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fromVal = document.getElementById('search-from').value.trim();
    const toVal = document.getElementById('search-to').value.trim();
    const dateVal = document.getElementById('search-date').value;
    const classVal = document.getElementById('search-class').value;
    const quotaVal = document.getElementById('search-quota').value;
    const tatkalVal = (quotaVal === 'TATKAL' || quotaVal === 'PREMIUM_TATKAL');

    state.searchParams = {
      from: fromVal,
      to: toVal,
      date: dateVal,
      coachClass: classVal,
      isTatkal: tatkalVal,
      quota: quotaVal
    };

    try {
      // Loader state
      const btn = e.target.querySelector('button');
      btn.innerHTML = '<span class="inline-block animate-spin mr-2">⏳</span>Searching...';
      btn.disabled = true;

      // API request to search trains
      const results = await apiRequest(`/api/trains/search?from=${encodeURIComponent(fromVal)}&to=${encodeURIComponent(toVal)}&date=${dateVal}${classVal ? `&class=${classVal}` : ''}`);

      // Map backend response structures into a flat format that frontend app.js expects natively
      const mappedResults = results.map(item => {
        return {
          train_number: item.train.train_number,
          train_name: item.train.train_name,
          source: item.train.from_station_name || item.train.from_station_code,
          destination: item.train.to_station_name || item.train.to_station_code,
          from_station_code: item.train.from_station_code,
          to_station_code: item.train.to_station_code,
          departure: item.train.departure,
          arrival: item.train.arrival,
          duration: `${item.train.duration_h}h ${item.train.duration_m}m`,
          distance_km: item.train.distance_km,
          schedule: [
            { station_code: fromVal.trim().toUpperCase(), departure_time: item.train.departure ? item.train.departure.substring(0, 5) : '08:00' },
            { station_code: toVal.trim().toUpperCase(), arrival_time: item.train.arrival ? item.train.arrival.substring(0, 5) : '16:30' }
          ],
          classes: item.availabilities.map(av => {
            return {
              coach_class: av.coach_class,
              fare: av.fare,
              available_seats: av.available_seats,
              rac_count: av.rac_count,
              wl_count: av.wl_count,
              status: av.status.startsWith('AVAILABLE') ? 'AVAILABLE' : (av.status.startsWith('RAC') ? 'RAC' : 'WAITLIST')
            };
          })
        };
      });
      state.searchResults = mappedResults;
      
      navigateTo('results');
    } catch (err) {
      showAlert(err.message);
    }
  });

  renderFooter();
}

function setupStationAutocomplete(inputId, suggestionsId) {
  const input = document.getElementById(inputId);
  const sugBox = document.getElementById(suggestionsId);

  input.addEventListener('input', debounce(async (e) => {
    const q = e.target.value.trim();
    if (q.length < 2) {
      sugBox.innerHTML = '';
      sugBox.classList.add('hidden');
      return;
    }

    try {
      const stations = await apiRequest(`/api/stations/search?q=${encodeURIComponent(q)}`);
      if (stations.length === 0) {
        sugBox.innerHTML = '<div class="px-4 py-3 text-slate-400 text-sm">No stations found</div>';
      } else {
        sugBox.innerHTML = stations.map(s => `
          <div class="px-4 py-2 hover:bg-slate-50 cursor-pointer text-sm font-semibold flex items-center justify-between" data-code="${s.station_code}">
            <span>${s.station_name}</span>
            <span class="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-xs">${s.station_code}</span>
          </div>
        `).join('');
      }
      sugBox.classList.remove('hidden');

      // Click event
      sugBox.querySelectorAll('div').forEach(item => {
        item.addEventListener('click', () => {
          input.value = item.getAttribute('data-code');
          sugBox.classList.add('hidden');
          sugBox.innerHTML = '';
        });
      });
    } catch (err) {
      console.error(err);
    }
  }, 300));

  // Hide autocomplete on outer click
  document.addEventListener('click', (e) => {
    if (e.target !== input && e.target !== sugBox) {
      sugBox.classList.add('hidden');
    }
  });
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// ==========================================
// VIEW: Search Results Page
// ==========================================
function renderResults() {
  const container = document.getElementById('app');
  
  const searchBar = `
    <div class="bg-primary text-white py-6 px-6 shadow-md border-b border-primary-dark">
      <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 class="text-xl font-bold font-serif flex items-center gap-2">
            <span>${state.searchParams.from}</span>
            <span class="text-accent">➔</span>
            <span>${state.searchParams.to}</span>
          </h2>
          <p class="text-xs text-slate-300 font-semibold mt-1">
            📅 ${state.searchParams.date} | Class: ${state.searchParams.coachClass || 'All'} | Quota: ${state.searchParams.quota || (state.searchParams.isTatkal ? 'TATKAL' : 'GENERAL')}
          </p>
        </div>
        <button onclick="navigateTo('home')" class="glow-btn bg-white/10 hover:bg-white/20 border border-white/20 text-white px-5 py-2 rounded-xl text-sm font-semibold transition">
          Modify Search
        </button>
      </div>
    </div>
  `;

  if (state.searchResults.length === 0) {
    container.innerHTML = `
      ${searchBar}
      <div class="max-w-md mx-auto py-24 text-center space-y-4">
        <span class="text-5xl">🚫</span>
        <h3 class="text-xl font-bold font-serif text-slate-800">No Trains Found</h3>
        <p class="text-slate-600">No trains operate on this date between the chosen stations. Try another date or neighboring station codes.</p>
        <button onclick="navigateTo('home')" class="glow-btn bg-primary text-white px-6 py-2.5 rounded-xl font-semibold shadow-md transition">Go Back</button>
      </div>
    `;
    renderFooter();
    return;
  }

  // Generate train cards
  let trainCardsHTML = '';
  state.searchResults.forEach(train => {
    const isTatkal = state.searchParams.isTatkal;
    const schedule = train.schedule || [];
    
    // Find departure and arrival times from schedule matching search
    const depStation = schedule.find(s => s.station_code === state.searchParams.from);
    const arrStation = schedule.find(s => s.station_code === state.searchParams.to);
    
    const depTime = depStation ? depStation.departure_time : '08:00';
    const arrTime = arrStation ? arrStation.arrival_time : '16:30';
    const duration = train.duration || '8h 30m';

    // Build class boxes
    let classesHTML = '';
    const classes = train.classes || [];
    classes.forEach(c => {
      // Filter by search coach class if specified
      if (state.searchParams.coachClass && c.coach_class !== state.searchParams.coachClass) return;

      const availStatus = c.status;
      const isAvailable = availStatus === 'AVAILABLE';
      let statusColor = 'text-success bg-green-50 border-green-200';
      if (availStatus === 'WAITLIST') statusColor = 'text-warning bg-amber-50 border-amber-200';
      if (availStatus === 'RAC') statusColor = 'text-blue-600 bg-blue-50 border-blue-200';

      classesHTML += `
        <div 
          onclick="selectTrainClass('${train.train_number}', '${c.coach_class}')"
          class="premium-card cursor-pointer border p-4 rounded-xl flex flex-col justify-between hover:border-accent hover:ring-2 hover:ring-accent/15 transition relative ${
            state.selectedTrain?.train_number === train.train_number && state.selectedClass?.coach_class === c.coach_class ? 'border-accent ring-2 ring-accent/30 bg-accent/5' : 'bg-white border-slate-200'
          }"
        >
          <div class="flex items-center justify-between">
            <span class="font-bold text-slate-800 text-sm">${c.coach_class}</span>
            <span class="text-xs font-bold text-slate-500">₹${c.fare}</span>
          </div>
          <div class="mt-3">
            <span class="text-xs font-bold px-2.5 py-1 rounded-full ${statusColor}">
              ${c.available_seats > 0 ? `AVL ${c.available_seats}` : ''}
              ${c.status === 'WAITLIST' ? `WL ${c.wl_count}` : ''}
              ${c.status === 'RAC' ? `RAC ${c.rac_count}` : ''}
            </span>
          </div>
        </div>
      `;
    });

    trainCardsHTML += `
      <div class="premium-card p-6 border border-slate-100 mb-6 relative">
        ${isTatkal ? `
          <div class="absolute top-0 right-0 bg-accent text-white font-extrabold text-[10px] px-4 py-1.5 rounded-bl-xl uppercase tracking-widest tatkal-active-glow">
            🚨 Tatkal Quota
          </div>
        ` : ''}
        
        <!-- Header Info -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 class="text-lg font-serif font-bold text-primary flex items-center gap-2">
              <span>${train.train_name}</span>
              <span class="bg-primary/10 text-primary text-xs px-2.5 py-1 rounded-md">#${train.train_number}</span>
            </h3>
            <p class="text-xs text-slate-400 font-semibold mt-1">Runs: Mon, Wed, Fri | Base Route: ${train.source} to ${train.destination}</p>
          </div>
          
          <div class="flex items-center gap-6">
            <div class="text-right">
              <span class="text-md font-bold text-slate-800">${depTime}</span>
              <p class="text-xs text-slate-400 font-semibold">${state.searchParams.from}</p>
            </div>
            
            <div class="flex flex-col items-center">
              <span class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">${duration}</span>
              <div class="w-20 h-[2px] bg-slate-200 relative my-1">
                <div class="absolute -top-1 left-1/2 -translate-x-1/2 text-xs">🚂</div>
              </div>
            </div>
            
            <div class="text-left">
              <span class="text-md font-bold text-slate-800">${arrTime}</span>
              <p class="text-xs text-slate-400 font-semibold">${state.searchParams.to}</p>
            </div>
          </div>
        </div>

        <!-- Coach Classes Grid -->
        <div class="mt-6">
          <h4 class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Available Classes (Click to book)</h4>
          <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            ${classesHTML}
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = `
    ${searchBar}
    <div class="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-8">
      <!-- Search Results Area -->
      <div class="lg:col-span-8">
        <h2 class="text-xl font-serif font-bold text-slate-800 mb-6">Available Trains</h2>
        ${trainCardsHTML}
      </div>

      <!-- Quick Action / Booking Overview Bar -->
      <div class="lg:col-span-4">
        <div class="glass-panel sticky top-24 rounded-2xl p-6 shadow-lg border border-white space-y-6">
          <h3 class="text-lg font-serif font-bold text-slate-800">Booking Summary</h3>
          
          <div id="booking-sidebar-details" class="space-y-4">
            <div class="text-slate-400 text-sm text-center py-6">
              Select a coach class option on any train to initiate booking flow.
            </div>
          </div>

          <button 
            id="proceed-booking-btn" 
            disabled
            onclick="proceedToBookingForm()"
            class="glow-btn w-full bg-slate-200 text-slate-500 py-3.5 rounded-xl font-bold text-sm shadow-md transition uppercase tracking-wider disabled:cursor-not-allowed"
          >
            Book Now
          </button>
        </div>
      </div>
    </div>
  `;

  // Start real-time seat WS connections
  setupSeatWebSocket();

  renderFooter();
}

function selectTrainClass(trainNumber, coachClass) {
  const train = state.searchResults.find(t => t.train_number === trainNumber);
  const cClass = train.classes.find(c => c.coach_class === coachClass);

  state.selectedTrain = train;
  state.selectedClass = cClass;

  // Update UI selection highlights
  renderResults();

  // Populate sidebar
  const isTatkal = state.searchParams.isTatkal;
  const sidebar = document.getElementById('booking-sidebar-details');
  const proceedBtn = document.getElementById('proceed-booking-btn');

  sidebar.innerHTML = `
    <div class="space-y-4">
      <div class="flex justify-between items-center pb-3 border-b border-slate-100">
        <div>
          <h4 class="font-bold text-slate-800">${train.train_name}</h4>
          <p class="text-xs text-slate-400">Train #${train.train_number}</p>
        </div>
        <span class="bg-accent/10 text-accent font-bold px-3 py-1 rounded-lg text-xs uppercase">${coachClass}</span>
      </div>
      
      <div class="flex justify-between items-center text-sm">
        <span class="text-slate-500 font-semibold">Seat Status:</span>
        <span class="font-bold text-success">
          ${cClass.available_seats > 0 ? `AVL ${cClass.available_seats}` : ''}
          ${cClass.status === 'WAITLIST' ? `WL ${cClass.wl_count}` : ''}
          ${cClass.status === 'RAC' ? `RAC ${cClass.rac_count}` : ''}
        </span>
      </div>

      <div class="flex justify-between items-center text-sm">
        <span class="text-slate-500 font-semibold">Fare (Per passenger):</span>
        <span class="font-bold text-slate-800">₹${cClass.fare}</span>
      </div>

      ${isTatkal ? `
        <div class="bg-accent/5 border border-accent/10 rounded-xl p-3.5 space-y-2">
          <div class="flex justify-between items-center text-xs">
            <span class="text-accent font-bold">Tatkal Window Premium:</span>
            <span class="font-extrabold text-accent">Included</span>
          </div>
          <p class="text-[10px] text-slate-400 leading-normal">
            Tatkal bookings enter a virtual waiting room before checkout. When you click Book, you will join the live server Tatkal queue.
          </p>
        </div>
      ` : ''}
    </div>
  `;

  proceedBtn.disabled = false;
  proceedBtn.classList.remove('bg-slate-200', 'text-slate-500');
  proceedBtn.classList.add('bg-accent', 'hover:bg-accent-light', 'text-white');
}

function setupSeatWebSocket() {
  if (state.searchResults.length === 0) return;
  
  // Connect to WS
  const trainNumber = state.searchResults[0].train_number; // Connect to the first train or dynamic
  const journeyDate = state.searchParams.date;
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url = `${protocol}//${window.location.host}/ws/seats/${trainNumber}/${journeyDate}`;
  
  try {
    state.wsSeatConn = new WebSocket(url);
    state.wsSeatConn.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === 'initial_availability') {
        console.log('WS Initial Seats Avail:', data.availabilities);
        // We can dynamically update the search results list if seat count shifts
        data.availabilities.forEach(item => {
          state.searchResults.forEach(train => {
            if (train.train_number === trainNumber) {
              const cClass = train.classes.find(c => c.coach_class === item.coach_class);
              if (cClass) {
                cClass.available_seats = item.available_seats;
                cClass.status = item.status;
                cClass.fare = item.fare;
              }
            }
          });
        });
      }
    };
  } catch (err) {
    console.error('WebSocket connecting failed:', err);
  }
}

async function proceedToBookingForm() {
  if (!state.token) {
    showAlert('Please sign in to proceed with booking tickets.');
    navigateTo('login');
    return;
  }
  
  // Proceed directly to waiting room if Tatkal, otherwise Booking page
  if (state.searchParams.isTatkal) {
    try {
      const res = await apiRequest('/api/bookings/tatkal/join', {
        method: 'POST',
        body: JSON.stringify({
          train_number: state.selectedTrain.train_number,
          journey_date: state.searchParams.date,
          coach_class: state.selectedClass.coach_class
        })
      });
      state.tatkalQueue = res;
      navigateTo('tatkal-queue');
    } catch (err) {
      showAlert(err.message);
    }
  } else {
    navigateTo('booking');
  }
}

// ==========================================
// VIEW: Tatkal Queue Waiting Room
// ==========================================
function renderTatkalQueue() {
  const container = document.getElementById('app');
  if (!state.tatkalQueue) {
    navigateTo('home');
    return;
  }

  container.innerHTML = `
    <div class="max-w-2xl mx-auto px-6 py-16">
      <div class="glass-panel rounded-2xl p-8 shadow-xl border border-white text-center space-y-6 tatkal-active-glow">
        <div class="flex justify-center">
          <div class="h-20 w-20 rounded-full bg-accent/15 flex items-center justify-center text-4xl animate-pulse">
            🚨
          </div>
        </div>

        <div class="space-y-2">
          <h2 class="text-2xl font-serif font-bold text-primary">Tatkal Booking Virtual Queue</h2>
          <p class="text-sm text-slate-500 font-semibold">Please do not refresh or close this window. You are in the active ticket queue.</p>
        </div>

        <!-- Progress Indicator -->
        <div class="space-y-2">
          <div class="flex justify-between items-center text-sm font-bold text-slate-600 px-1">
            <span id="queue-status-text">Checking queue status...</span>
            <span id="queue-pos-val">-</span>
          </div>
          <div class="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
            <div id="queue-progress-bar" class="h-full bg-accent transition-all duration-1000" style="width: 10%"></div>
          </div>
        </div>

        <!-- Train Details Card -->
        <div class="bg-slate-50 border border-slate-150 rounded-xl p-4 text-left grid grid-cols-2 gap-4">
          <div>
            <h4 class="text-xs text-slate-400 font-bold uppercase">Train</h4>
            <p class="text-sm font-semibold text-slate-800">${state.selectedTrain.train_name} (#${state.selectedTrain.train_number})</p>
          </div>
          <div>
            <h4 class="text-xs text-slate-400 font-bold uppercase">Journey Date</h4>
            <p class="text-sm font-semibold text-slate-800">${state.searchParams.date}</p>
          </div>
          <div>
            <h4 class="text-xs text-slate-400 font-bold uppercase">Coach Class</h4>
            <p class="text-sm font-semibold text-slate-800">${state.selectedClass.coach_class}</p>
          </div>
          <div>
            <h4 class="text-xs text-slate-400 font-bold uppercase">Joined At</h4>
            <p class="text-sm font-semibold text-slate-800">${new Date(state.tatkalQueue.joined_at).toLocaleTimeString()}</p>
          </div>
        </div>

        <div class="border-t border-slate-100 pt-6">
          <button 
            onclick="cancelTatkalQueue()"
            class="glow-btn bg-slate-150 text-slate-600 px-6 py-2.5 rounded-xl text-sm font-bold border border-slate-200 hover:bg-slate-200 transition"
          >
            Leave Queue
          </button>
        </div>
      </div>
    </div>
  `;

  // Start websocket monitoring
  setupTatkalWebSocket();
}

function setupTatkalWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url = `${protocol}//${window.location.host}/ws/tatkal/${state.selectedTrain.train_number}/${state.searchParams.date}/${state.selectedClass.coach_class}?user_id=${state.user.id}`;
  
  try {
    state.wsTatkalConn = new WebSocket(url);
    state.wsTatkalConn.onmessage = (e) => {
      const data = JSON.parse(e.data);
      console.log('Tatkal Queue WS message:', data);
      
      const statusText = document.getElementById('queue-status-text');
      const posVal = document.getElementById('queue-pos-val');
      const progress = document.getElementById('queue-progress-bar');
      
      if (!statusText) return;

      if (data.status === 'ACTIVE') {
        statusText.innerHTML = '🎉 Seat booking window unlocked! Redirecting...';
        posVal.innerHTML = 'READY';
        progress.style.width = '100%';
        showAlert('Tatkal seat unlocked! Proceeding to passenger details form.', 'success');
        
        setTimeout(() => {
          navigateTo('booking');
        }, 1500);
      } else if (data.status === 'WAITING') {
        statusText.innerHTML = `In waiting queue. Position ahead: ${data.position}`;
        posVal.innerHTML = `#${data.position}`;
        const pct = Math.max(15, 100 - (data.position * 20));
        progress.style.width = `${pct}%`;
      } else {
        // Expired or cancelled
        statusText.innerHTML = 'Queue window expired. Re-join queue.';
        showAlert('Your tatkal booking slot expired or was cancelled by the server.');
        navigateTo('home');
      }
    };
  } catch (err) {
    console.error(err);
  }
}

async function cancelTatkalQueue() {
  try {
    await apiRequest(`/api/bookings/tatkal/status?train_number=${state.selectedTrain.train_number}&journey_date=${state.searchParams.date}&coach_class=${state.selectedClass.coach_class}&status=EXPIRED`, {
      method: 'PUT'
    });
    showAlert('Successfully exited tatkal virtual waiting room.');
    navigateTo('home');
  } catch (err) {
    showAlert(err.message);
  }
}

// ==========================================
// VIEW: Booking / Passenger Form with SVG Seat Selection
// ==========================================
function renderBooking() {
  const container = document.getElementById('app');
  if (!state.selectedTrain || !state.selectedClass) {
    navigateTo('home');
    return;
  }

  // Generate Passenger form elements
  container.innerHTML = `
    <div class="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-8">
      <!-- Input details form -->
      <div class="lg:col-span-8 space-y-6">
        <h2 class="text-2xl font-serif font-bold text-slate-800 flex items-center gap-2">
          <span>Passenger Details Form</span>
          <span class="inline-block text-xs font-bold bg-primary/10 text-primary px-3 py-1 rounded-md uppercase">General Booking</span>
        </h2>

        <!-- Rail Nova Seat Allocation Info Banner -->
        <div class="bg-primary/5 border border-primary/10 rounded-2xl p-5 shadow-sm flex items-start gap-4">
          <span class="text-2xl mt-0.5">ℹ️</span>
          <div class="space-y-1">
            <h3 class="text-sm font-bold text-primary font-serif">Auto-Allocation Protocol Active</h3>
            <p class="text-xs text-slate-500 leading-normal font-medium">
              In accordance with standard Rail Nova rules, seat and coach allocations (e.g. S1/B2, lower/upper berths) are processed automatically by the Indian Railways centralized booking system based on availability and passenger berth preferences.
            </p>
          </div>
        </div>

        <form id="booking-passenger-form" class="space-y-6">
          <div id="passenger-rows-container" class="space-y-4">
            <!-- Rows injected here dynamically -->
          </div>

          <!-- Add Passenger Button -->
          <div class="flex justify-between items-center">
            <button 
              type="button" 
              onclick="addPassengerRow()"
              class="glow-btn flex items-center gap-1.5 text-primary hover:text-primary-light font-bold text-sm"
            >
              ➕ Add Another Passenger
            </button>
            <p class="text-xs text-slate-400 font-semibold">Maximum 6 passengers per booking booking session.</p>
          </div>

          <!-- Verification Details (Aadhaar / PAN / Mobile) -->
          <div class="bg-white border border-slate-100 rounded-2xl p-6 shadow-md space-y-4">
            <h3 class="text-md font-serif font-bold text-slate-800">Verification Details</h3>
            <p class="text-xs text-slate-400 font-semibold">Rail Nova requires validation of identity credentials of the primary booker before ticket allocation.</p>
            
            <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-xs text-amber-800 font-semibold">
              <span class="text-base leading-none">⚠️</span>
              <p>Note: Aadhaar Card and PAN Card are optional during booking checkout. However, please carry a valid original Aadhaar or PAN card during your journey for on-board verification by the Ticket Examiner (TTE).</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Aadhaar Card (12 Digits) <span class="text-slate-400 font-normal lowercase">(optional)</span></label>
                <input 
                  type="text" 
                  id="primary-aadhaar" 
                  placeholder="e.g. 123456789012"
                  value="${state.user?.aadhaar || ''}"
                  maxlength="12"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                />
              </div>

              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">PAN Card (10 Digits) <span class="text-slate-400 font-normal lowercase">(optional)</span></label>
                <input 
                  type="text" 
                  id="primary-pan" 
                  placeholder="e.g. ABCDE1234F"
                  value="${state.user?.pan || ''}"
                  maxlength="10"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                />
              </div>

              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Mobile Number (10 Digits)</label>
                <input 
                  type="text" 
                  id="primary-mobile" 
                  placeholder="e.g. 9876543210"
                  value="${state.user?.mobile || ''}"
                  maxlength="10"
                  class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition"
                  required
                />
              </div>
            </div>
          </div>

          <!-- Checkout Trigger Button -->
          <button 
            type="submit" 
            class="glow-btn w-full bg-accent hover:bg-accent-light text-white py-4 rounded-xl font-bold text-md shadow-lg transition duration-200 uppercase tracking-widest"
          >
            Initiate Booking & Hold Seats
          </button>
        </form>
      </div>

      <!-- Booking Lock Sidebar -->
      <div class="lg:col-span-4">
        <div class="glass-panel sticky top-24 rounded-2xl p-6 shadow-lg border border-white space-y-6">
          <h3 class="text-lg font-serif font-bold text-slate-800">Seat Hold Status</h3>
          
          <div class="bg-orange-50 border border-orange-100 rounded-xl p-4 text-center space-y-2">
            <span class="text-2xl animate-pulse inline-block">⏱️</span>
            <h4 class="text-sm font-bold text-slate-800">10-Minute Lockout Active</h4>
            <p class="text-xs text-slate-500 leading-normal">
              Upon initiating, your selected coach seats are locked out exclusively for your account for 10 minutes to verify payment details.
            </p>
          </div>

          <div class="space-y-3 pb-4 border-b border-slate-100">
            <div class="flex justify-between items-center text-xs">
              <span class="text-slate-400 font-bold uppercase">Train</span>
              <span class="font-bold text-slate-800">${state.selectedTrain.train_name}</span>
            </div>
            <div class="flex justify-between items-center text-xs">
              <span class="text-slate-400 font-bold uppercase">Journey Date</span>
              <span class="font-bold text-slate-800">${state.searchParams.date}</span>
            </div>
            <div class="flex justify-between items-center text-xs">
              <span class="text-slate-400 font-bold uppercase">Quota</span>
              <span class="font-bold text-accent">${state.searchParams.isTatkal ? 'Tatkal Quota' : 'General'}</span>
            </div>
          </div>

          <div class="flex justify-between items-center">
            <span class="text-slate-600 font-serif font-bold">Total Fare:</span>
            <span id="booking-total-fare" class="text-xl font-bold text-primary">₹${state.selectedClass.fare}</span>
          </div>
        </div>
      </div>
    </div>
  `;

  // Start with 1 passenger row
  addPassengerRow();

  // Submit trigger
  document.getElementById('booking-passenger-form').addEventListener('submit', handlePassengerFormSubmit);
}

function addPassengerRow() {
  const container = document.getElementById('passenger-rows-container');
  const rowCount = container.querySelectorAll('.passenger-row').length;
  
  if (rowCount >= 6) {
    showAlert('Maximum 6 passengers allowed in a single booking session.');
    return;
  }

  const row = document.createElement('div');
  row.className = 'passenger-row bg-white border border-slate-100 rounded-2xl p-6 shadow-md relative';
  row.innerHTML = `
    ${rowCount > 0 ? `
      <button 
        type="button" 
        onclick="removePassengerRow(this)"
        class="absolute top-4 right-4 text-xs font-bold text-red-500 hover:text-red-700"
      >
        ❌ Remove
      </button>
    ` : ''}
    <h3 class="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
      <span class="h-5 w-5 bg-primary/10 text-primary text-xs rounded-full flex items-center justify-center">${rowCount + 1}</span>
      Passenger Details
    </h3>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div>
        <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Name</label>
        <input 
          type="text" 
          name="name" 
          placeholder="Full Name" 
          class="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-primary/20 transition"
          required
        />
      </div>

      <div>
        <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Age</label>
        <input 
          type="number" 
          name="age" 
          placeholder="Age" 
          min="1" 
          max="120"
          class="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-primary/20 transition"
          required
        />
      </div>

      <div>
        <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Gender</label>
        <select 
          name="gender" 
          class="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-primary/20 transition"
          required
        >
          <option value="MALE">Male</option>
          <option value="FEMALE">Female</option>
          <option value="OTHER">Other</option>
        </select>
      </div>

      <div>
        <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Berth Preference</label>
        <select 
          name="berth_pref" 
          class="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-primary/20 transition"
          required
        >
          <option value="No Preference">No Preference</option>
          <option value="Lower">Lower</option>
          <option value="Middle">Middle</option>
          <option value="Upper">Upper</option>
          <option value="Side Lower">Side Lower</option>
          <option value="Side Upper">Side Upper</option>
        </select>
      </div>
    </div>
  `;
  container.appendChild(row);
  
  // Re-calculate Total Fare
  updateBookingTotalFare();
}

window.removePassengerRow = function(btn) {
  btn.closest('.passenger-row').remove();
  
  // Re-adjust numbers & seat indexes
  const container = document.getElementById('passenger-rows-container');
  container.querySelectorAll('.passenger-row').forEach((row, i) => {
    row.querySelector('h3 span').innerText = i + 1;
  });

  updateBookingTotalFare();
};

function updateBookingTotalFare() {
  const rowCount = document.querySelectorAll('.passenger-row').length;
  const baseFare = state.selectedClass.fare;
  const total = rowCount * baseFare;
  const container = document.getElementById('booking-total-fare');
  if (container) container.innerText = `₹${total}`;
}

async function handlePassengerFormSubmit(e) {
  e.preventDefault();

  const aadhaar = document.getElementById('primary-aadhaar').value.trim();
  const pan = document.getElementById('primary-pan').value.trim();
  const mobile = document.getElementById('primary-mobile').value.trim();

  // Validate credentials (only validate if provided since they are optional)
  if (aadhaar && !/^\d{12}$/.test(aadhaar)) {
    showAlert('Aadhaar card must be exactly 12 numeric digits.');
    return;
  }
  if (pan && !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan)) {
    showAlert('PAN card number format invalid. (e.g. ABCDE1234F)');
    return;
  }
  if (!/^[6-9]\d{9}$/.test(mobile)) {
    showAlert('Mobile number must be exactly 10 digits starting with 6-9.');
    return;
  }

  // Parse passengers
  const rowNodes = document.querySelectorAll('.passenger-row');
  const passengers = [];
  rowNodes.forEach((node, i) => {
    const name = node.querySelector('[name="name"]').value.trim();
    const age = parseInt(node.querySelector('[name="age"]').value);
    const gender = node.querySelector('[name="gender"]').value;
    const berth_pref = node.querySelector('[name="berth_pref"]').value;
    
    passengers.push({
      name,
      age,
      gender,
      berth_pref
    });
  });

  // Call create-booking endpoint
  try {
    const payload = {
      train_number: state.selectedTrain.train_number,
      journey_date: state.searchParams.date,
      coach_class: state.selectedClass.coach_class,
      is_tatkal: state.searchParams.isTatkal,
      from_station: state.searchParams.from,
      to_station: state.searchParams.to,
      passengers
    };

    const bookingRes = await apiRequest('/api/bookings', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    state.activeBooking = bookingRes;
    showAlert('Seats locked out successfully! Proceeding to secure checkout payment window.', 'success');
    navigateTo('payment');
  } catch (err) {
    showAlert(err.message);
  }
}

// ==========================================
// VIEW: Payment Simulator
// ==========================================
async function renderPayment() {
  const container = document.getElementById('app');
  if (!state.activeBooking) {
    navigateTo('home');
    return;
  }

  let walletBalance = 0.0;
  try {
    const res = await apiRequest('/api/payments/ewallet/balance');
    walletBalance = res.balance;
  } catch (err) {
    walletBalance = state.user?.ewallet_balance || 0.0;
  }

  container.innerHTML = `
    <div class="max-w-4xl mx-auto px-6 py-12">
      <div class="glass-panel rounded-2xl p-8 shadow-xl border border-white space-y-6">
        
        <!-- Header status -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-slate-100">
          <div>
            <span class="inline-block text-xs font-bold bg-amber-50 text-warning px-3 py-1 rounded-md uppercase border border-amber-200 mb-2">⏱️ Hold Reserved - Payment Pending</span>
            <h2 class="text-2xl font-serif font-bold text-slate-800">Secure Payment Gateway</h2>
            <p class="text-xs text-slate-400 font-semibold mt-1">PNR: ${state.activeBooking.pnr} | Reference Booking ID: #${state.activeBooking.id}</p>
          </div>
          <div class="text-right">
            <span class="text-slate-400 text-xs font-bold uppercase block">Amount Payable</span>
            <span class="text-3xl font-extrabold text-primary">₹${state.activeBooking.total_fare}</span>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-12 gap-8 mt-6">
          <!-- Left payment options selector -->
          <div class="md:col-span-8 space-y-6">
            <h3 class="text-md font-serif font-bold text-slate-800">Choose Payment Method</h3>
            
            <div class="space-y-4">
              <!-- Option eWallet -->
              <label class="premium-card p-4 flex items-center justify-between border cursor-pointer hover:border-primary transition bg-slate-50 border-slate-200">
                <div class="flex items-center gap-4">
                  <input type="radio" name="pay-method" value="wallet" checked class="h-5 w-5 accent-primary cursor-pointer"/>
                  <div>
                    <span class="text-sm font-bold text-slate-800">Rail Nova eWallet</span>
                    <p class="text-[10px] text-slate-400 font-semibold">Pay instantly from local account balance (Available: ₹${walletBalance.toFixed(2)})</p>
                  </div>
                </div>
                <span class="text-2xl">💼</span>
              </label>

              <!-- Option UPI -->
              <label class="premium-card p-4 flex items-center justify-between border cursor-pointer hover:border-primary transition bg-slate-50 border-slate-200">
                <div class="flex items-center gap-4">
                  <input type="radio" name="pay-method" value="upi" class="h-5 w-5 accent-primary cursor-pointer"/>
                  <div>
                    <span class="text-sm font-bold text-slate-800">BHIM UPI / GPAY / PhonePe</span>
                    <p class="text-[10px] text-slate-400 font-semibold">Instant verification via VPA</p>
                  </div>
                </div>
                <span class="text-2xl">📱</span>
              </label>

              <!-- Option Card -->
              <label class="premium-card p-4 flex items-center justify-between border cursor-pointer hover:border-primary transition bg-slate-50 border-slate-200">
                <div class="flex items-center gap-4">
                  <input type="radio" name="pay-method" value="card" class="h-5 w-5 accent-primary cursor-pointer"/>
                  <div>
                    <span class="text-sm font-bold text-slate-800">Credit / Debit Card</span>
                    <p class="text-[10px] text-slate-400 font-semibold">Visa, MasterCard, RuPay</p>
                  </div>
                </div>
                <span class="text-2xl">💳</span>
              </label>

              <!-- Option Net Banking -->
              <label class="premium-card p-4 flex items-center justify-between border cursor-pointer hover:border-primary transition bg-slate-50 border-slate-200">
                <div class="flex items-center gap-4">
                  <input type="radio" name="pay-method" value="nb" class="h-5 w-5 accent-primary cursor-pointer"/>
                  <div>
                    <span class="text-sm font-bold text-slate-800">Net Banking</span>
                    <p class="text-[10px] text-slate-400 font-semibold">All major Indian nationalized banks</p>
                  </div>
                </div>
                <span class="text-2xl">🏛️</span>
              </label>
            </div>

            <!-- Virtual verification controls -->
            <div id="payment-input-area" class="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-4">
              <!-- Default: wallet details -->
            </div>

            <button 
              onclick="triggerMockPaymentCheckout()"
              class="glow-btn w-full bg-success hover:bg-green-700 text-white py-4 rounded-xl font-bold text-md shadow-lg transition uppercase tracking-wider"
            >
              Pay Securely ₹${state.activeBooking.total_fare}
            </button>
          </div>

          <!-- Right safety guidelines -->
          <div class="md:col-span-4 space-y-6">
            <div class="bg-slate-50 border border-slate-150 rounded-2xl p-5 space-y-3">
              <h4 class="text-xs text-slate-400 font-bold uppercase">Booking Summary</h4>
              <div class="space-y-2 text-xs font-semibold text-slate-600">
                <div class="flex justify-between">
                  <span>Base fare:</span>
                  <span class="text-slate-800">₹${state.activeBooking.total_fare}</span>
                </div>
                <div class="flex justify-between">
                  <span>Concession Fee:</span>
                  <span class="text-slate-800">₹0</span>
                </div>
                <div class="flex justify-between border-t border-slate-200 pt-2 font-bold text-slate-800 text-sm">
                  <span>Total Payable:</span>
                  <span>₹${state.activeBooking.total_fare}</span>
                </div>
              </div>
            </div>

            <div class="text-slate-400 text-[10px] leading-normal flex gap-2">
              <span class="text-lg">🔒</span>
              <span>Your payment credentials are encrypted using bank-grade security protocols. Real currency is simulated.</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  `;

  // Render initial input area for wallet (since it's checked by default)
  const initialArea = document.getElementById('payment-input-area');
  const fareVal = state.activeBooking.total_fare;
  const hasSufficientInitial = walletBalance >= fareVal;
  initialArea.innerHTML = `
    <div class="space-y-3">
      <h4 class="text-xs font-bold text-slate-500 uppercase">Confirm eWallet Checkout</h4>
      <div class="flex justify-between items-center bg-slate-50 rounded-xl p-3 border border-slate-100 text-xs font-semibold">
        <span class="text-slate-500">Available Balance:</span>
        <span class="${hasSufficientInitial ? 'text-success' : 'text-error'} font-bold">₹${walletBalance.toFixed(2)}</span>
      </div>
      <div class="flex justify-between items-center bg-slate-50 rounded-xl p-3 border border-slate-100 text-xs font-semibold">
        <span class="text-slate-500">Amount to Deduct:</span>
        <span class="text-primary font-bold">₹${fareVal.toFixed(2)}</span>
      </div>
      ${!hasSufficientInitial ? `
        <div class="text-xs font-semibold text-error bg-red-50 border border-red-200 rounded-xl p-3 flex gap-2">
          <span>⚠️</span>
          <p>Insufficient balance! Please go to your Profile and top up your eWallet.</p>
        </div>
      ` : `
        <div class="text-xs font-semibold text-success bg-green-50 border border-green-200 rounded-xl p-3 flex gap-2">
          <span>✅</span>
          <p>Instant checkout active. No payment gateways redirecting required!</p>
        </div>
      `}
    </div>
  `;

  // Option switch mapping
  document.querySelectorAll('input[name="pay-method"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      const area = document.getElementById('payment-input-area');
      if (e.target.value === 'wallet') {
        const hasSufficient = walletBalance >= fareVal;
        area.innerHTML = `
          <div class="space-y-3">
            <h4 class="text-xs font-bold text-slate-500 uppercase">Confirm eWallet Checkout</h4>
            <div class="flex justify-between items-center bg-slate-50 rounded-xl p-3 border border-slate-100 text-xs font-semibold">
              <span class="text-slate-500">Available Balance:</span>
              <span class="${hasSufficient ? 'text-success' : 'text-error'} font-bold">₹${walletBalance.toFixed(2)}</span>
            </div>
            <div class="flex justify-between items-center bg-slate-50 rounded-xl p-3 border border-slate-100 text-xs font-semibold">
              <span class="text-slate-500">Amount to Deduct:</span>
              <span class="text-primary font-bold">₹${fareVal.toFixed(2)}</span>
            </div>
            ${!hasSufficient ? `
              <div class="text-xs font-semibold text-error bg-red-50 border border-red-200 rounded-xl p-3 flex gap-2">
                <span>⚠️</span>
                <p>Insufficient balance! Please go to your Profile and top up your eWallet.</p>
              </div>
            ` : `
              <div class="text-xs font-semibold text-success bg-green-50 border border-green-200 rounded-xl p-3 flex gap-2">
                <span>✅</span>
                <p>Instant checkout active. No payment gateways redirecting required!</p>
              </div>
            `}
          </div>
        `;
      } else if (e.target.value === 'upi') {
        area.innerHTML = `
          <div>
            <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Enter Virtual Payment Address (VPA)</label>
            <input type="text" id="vpa-address" placeholder="e.g. user@okhdfcbank" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"/>
          </div>
        `;
      } else if (e.target.value === 'card') {
        area.innerHTML = `
          <div class="space-y-4">
            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Card Number</label>
              <input type="text" placeholder="1234 5678 9012 3456" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"/>
            </div>
            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Expiry Date</label>
                <input type="text" placeholder="MM/YY" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"/>
              </div>
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">CVV</label>
                <input type="password" placeholder="***" class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"/>
              </div>
            </div>
          </div>
        `;
      } else {
        area.innerHTML = `
          <div>
            <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Choose Bank</label>
            <select class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition">
              <option>State Bank of India</option>
              <option>HDFC Bank</option>
              <option>ICICI Bank</option>
              <option>Punjab National Bank</option>
            </select>
          </div>
        `;
      }
    });
  });
}

async function triggerMockPaymentCheckout() {
  const method = document.querySelector('input[name="pay-method"]:checked').value;

  try {
    if (method === 'wallet') {
      const res = await apiRequest('/api/payments/pay-via-wallet', {
        method: 'POST',
        body: JSON.stringify({ booking_id: state.activeBooking.id })
      });
      if (res.status === 'SUCCESS') {
        showAlert('Payment transaction completed successfully using eWallet! Your ticket has been confirmed.', 'success');
        navigateTo('history');
      }
      return;
    }

    // Standard simulated gateway
    // 1. Create order
    const orderRes = await apiRequest('/api/payments/create-order', {
      method: 'POST',
      body: JSON.stringify({ booking_id: state.activeBooking.id })
    });
    
    // 2. Verify payment (Mock verification)
    const payload = {
      razorpay_order_id: orderRes.order_id,
      razorpay_payment_id: `pay_mock_${Math.random().toString(36).substr(2, 9)}`,
      razorpay_signature: 'mock_signature_verification_key_hash'
    };

    const verifyRes = await apiRequest('/api/payments/verify', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    if (verifyRes.status === 'SUCCESS') {
      showAlert('Payment transaction completed successfully! Your ticket has been confirmed.', 'success');
      navigateTo('history');
    } else {
      throw new Error('Verification failed.');
    }
  } catch (err) {
    showAlert(err.message);
  }
}

// ==========================================
// VIEW: Booking History / PNR status inquiry
// ==========================================
async function renderHistory() {
  const container = document.getElementById('app');
  container.innerHTML = `
    <div class="max-w-7xl mx-auto px-6 py-12 space-y-10">
      
      <!-- PNR Search Panel -->
      <div class="glass-panel rounded-2xl p-6 shadow-md border border-white">
        <h3 class="text-lg font-serif font-bold text-slate-800 mb-4">Query PNR Status</h3>
        <div class="flex flex-col sm:flex-row gap-4">
          <input 
            type="text" 
            id="pnr-input" 
            placeholder="Enter 10-Digit PNR Number" 
            maxlength="10"
            class="flex-1 px-4 py-3 rounded-xl border border-slate-200 focus:ring-primary/20 transition text-sm font-semibold tracking-wider"
          />
          <button 
            onclick="searchPNR()"
            class="glow-btn bg-primary hover:bg-primary-light text-white px-8 py-3 rounded-xl font-bold text-sm shadow-md transition"
          >
            Check Status
          </button>
        </div>
        <div id="pnr-result-box" class="mt-6 hidden"></div>
      </div>

      <!-- History Bookings List -->
      <div class="space-y-6">
        <h2 class="text-2xl font-serif font-bold text-slate-800">Your Booked Tickets</h2>
        <div id="bookings-history-list" class="space-y-6">
          <div class="text-slate-400 text-sm py-12 text-center">Fetching your booking logs from database...</div>
        </div>
      </div>

    </div>
  `;

  // Fetch list
  try {
    const list = await apiRequest('/api/bookings');
    state.bookingHistory = list;
    renderBookingsHistoryList();
  } catch (err) {
    showAlert(err.message);
  }

  renderFooter();
}

function renderBookingsHistoryList() {
  const listContainer = document.getElementById('bookings-history-list');
  if (state.bookingHistory.length === 0) {
    listContainer.innerHTML = `
      <div class="bg-white border border-slate-100 rounded-2xl p-12 text-center space-y-4">
        <span class="text-4xl">🎫</span>
        <h4 class="text-md font-bold text-slate-800">No Tickets Booked Yet</h4>
        <p class="text-slate-400 text-xs">Search trains and initiate booking to see your reservation records here.</p>
      </div>
    `;
    return;
  }

  let html = '';
  state.bookingHistory.forEach(b => {
    let statusClass = 'text-success bg-green-50 border-green-200';
    if (b.status === 'PENDING') statusClass = 'text-warning bg-amber-50 border-amber-200';
    if (b.status === 'CANCELLED') statusClass = 'text-slate-400 bg-slate-50 border-slate-200';

    html += `
      <div class="premium-card border border-slate-100 p-6 bg-white space-y-6">
        
        <!-- Header -->
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-100">
          <div>
            <h3 class="font-serif font-bold text-md text-primary">${b.train_name}</h3>
            <p class="text-xs text-slate-400 font-semibold mt-1">Train #${b.train_number} | Date: ${b.journey_date} | Class: ${b.coach_class}</p>
          </div>
          
          <div class="flex items-center gap-3">
            <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">PNR ${b.pnr}</span>
            <span class="inline-block text-xs font-bold px-3 py-1 rounded-full border ${statusClass}">
              ${b.status}
            </span>
          </div>
        </div>

        <!-- Passengers table list -->
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-slate-100 text-slate-400 uppercase font-bold">
                <th class="py-2.5">Name</th>
                <th class="py-2.5">Age/Gender</th>
                <th class="py-2.5">Berth Assignment</th>
                <th class="py-2.5">Current Status</th>
              </tr>
            </thead>
            <tbody>
              ${b.passengers.map(p => `
                <tr class="border-b border-slate-50 text-slate-700 font-semibold">
                  <td class="py-3">${p.name}</td>
                  <td class="py-3">${p.age} / ${p.gender}</td>
                  <td class="py-3 font-mono text-slate-500">${p.coach_number && p.seat_number ? `${p.coach_number} / Seat ${p.seat_number} ${p.berth_type ? `(${p.berth_type})` : ''}` : 'Unassigned (WL)'}</td>
                  <td class="py-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
                      p.status === 'CNF' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                    }">
                      ${p.status}
                    </span>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <!-- Cancellation controls -->
        <div class="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 pt-4 border-t border-slate-100 mt-4">
          <div>
            ${b.status !== 'CANCELLED' ? `
              <button 
                onclick="window.downloadTicketPDF('${b.pnr}')"
                class="glow-btn text-xs font-bold bg-primary/10 text-primary hover:bg-primary/20 px-4 py-2 rounded-xl transition flex items-center gap-1.5"
              >
                📄 Download e-Ticket (PDF)
              </button>
            ` : `
              <button 
                onclick="window.downloadCancellationPDF('${b.pnr}')"
                class="glow-btn text-xs font-bold bg-red-50 text-red-600 hover:bg-red-100 px-4 py-2 rounded-xl transition flex items-center gap-1.5"
              >
                📄 Download Cancellation Slip (PDF)
              </button>
            `}
          </div>
          
          ${b.status === 'CONFIRMED' || b.status === 'PENDING' ? `
            <div>
              <button 
                onclick="cancelTicket('${b.pnr}')"
                class="glow-btn text-xs font-bold text-red-500 hover:text-red-700 border border-red-100 px-4 py-2 rounded-xl hover:bg-red-50 transition"
              >
                Cancel Reservation
              </button>
            </div>
          ` : ''}
        </div>

      </div>
    `;
  });
  listContainer.innerHTML = html;
}

async function searchPNR() {
  const pnr = document.getElementById('pnr-input').value.trim();
  if (!pnr || pnr.length !== 10) {
    showAlert('Please enter a valid 10-digit PNR number.');
    return;
  }

  const box = document.getElementById('pnr-result-box');
  box.innerHTML = '<span class="inline-block animate-spin mr-2">⏳</span>Searching PNR records...';
  box.classList.remove('hidden');

  try {
    const booking = await apiRequest(`/api/bookings/${pnr}`);
    box.innerHTML = `
      <div class="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 text-sm font-semibold">
        <div class="flex justify-between items-center pb-3 border-b border-slate-200">
          <div>
            <h4 class="font-bold text-primary">${booking.train_name}</h4>
            <p class="text-xs text-slate-400 mt-1">Date: ${booking.journey_date} | Class: ${booking.coach_class}</p>
          </div>
          <span class="inline-block text-xs font-bold px-3 py-1 rounded bg-slate-200 text-slate-700 uppercase">${booking.status}</span>
        </div>
        
        <div class="space-y-2">
          <p class="text-xs text-slate-400 font-bold uppercase tracking-wider">Passenger Allocation</p>
          ${booking.passengers.map(p => `
            <div class="flex justify-between items-center text-xs pb-1.5 border-b border-slate-100">
              <span class="text-slate-700 font-bold">${p.name}</span>
              <span class="font-mono text-slate-500">${p.coach_number && p.seat_number ? `${p.coach_number} / Seat ${p.seat_number} ${p.berth_type ? `(${p.berth_type})` : ''}` : 'Unassigned (WL)'}</span>
              <span class="font-bold text-success">${p.status}</span>
            </div>
          `).join('')}
        </div>

        <!-- e-Ticket download option directly on PNR lookup -->
        <div class="flex justify-end pt-2 border-t border-slate-200">
          ${booking.status !== 'CANCELLED' ? `
            <button 
              onclick="window.downloadTicketPDF('${booking.pnr}')"
              class="glow-btn text-xs font-bold bg-primary hover:bg-primary-light text-white px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow-sm"
            >
              📄 Download e-Ticket (PDF)
            </button>
          ` : `
            <button 
              onclick="window.downloadCancellationPDF('${booking.pnr}')"
              class="glow-btn text-xs font-bold bg-red-50 text-red-600 hover:bg-red-100 px-4 py-2 rounded-xl transition flex items-center gap-1.5"
            >
              📄 Download Cancellation Slip (PDF)
            </button>
          `}
        </div>
      </div>
    `;
  } catch (err) {
    box.innerHTML = `<div class="bg-red-50 text-red-700 border border-red-200 rounded-xl p-4 text-xs font-bold">${err.message}</div>`;
  }
}

async function cancelTicket(pnr) {
  if (!confirm('Are you sure you want to cancel this train reservation? Cancellation fees may apply.')) return;
  try {
    await apiRequest(`/api/bookings/${pnr}`, { method: 'DELETE' });
    showAlert('Reservation cancelled successfully. Refunds will be initiated to your bank.', 'success');
    renderHistory();
  } catch (err) {
    showAlert(err.message);
  }
}

// ==========================================
// VIEW: Profile Page & Password Update
// ==========================================
function renderProfile() {
  const container = document.getElementById('app');
  if (!state.user) {
    navigateTo('home');
    return;
  }

  container.innerHTML = `
    <div class="max-w-4xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
      
      <!-- Profile Card & Wallet Management -->
      <div class="md:col-span-1 space-y-6">
        <!-- User Info Card -->
        <div class="bg-white border border-slate-100 rounded-2xl p-6 shadow-md text-center space-y-4">
          <div class="flex justify-center">
            <div class="h-24 w-24 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-3xl font-serif">
              ${state.user.name.charAt(0).toUpperCase()}
            </div>
          </div>
          <div>
            <h3 class="font-serif font-bold text-lg text-slate-800">${state.user.name}</h3>
            <p class="text-xs text-slate-400 font-semibold mt-1">${state.user.email}</p>
          </div>
          <div class="border-t border-slate-100 pt-4 flex flex-col gap-2 text-left text-xs font-semibold text-slate-500">
            <div>🔑 User ID: <span class="font-mono text-slate-800">${state.user.id.substring(0, 8)}...</span></div>
            <div>📄 Aadhaar: <span class="font-mono text-slate-800">${state.user.aadhaar || 'Unverified'}</span></div>
            <div>💳 PAN: <span class="font-mono text-slate-800">${state.user.pan || 'Unverified'}</span></div>
          </div>
        </div>

        <!-- eWallet Quick Stats -->
        <div class="bg-white border border-slate-100 rounded-2xl p-6 shadow-md space-y-4">
          <div class="flex justify-between items-center pb-2 border-b border-slate-100">
            <h3 class="text-xs font-serif font-bold text-slate-800 flex items-center gap-1">
              💼 eWallet Balance
            </h3>
            <span class="text-base font-extrabold text-primary" id="wallet-profile-balance">₹0.00</span>
          </div>
          
          <form id="wallet-topup-form" class="space-y-3">
            <label class="block text-[9px] font-bold text-slate-400 uppercase tracking-wide">Top Up Wallet Account</label>
            <div class="flex gap-2">
              <input 
                type="number" 
                id="wallet-topup-amount" 
                placeholder="Amount (₹)" 
                min="10" 
                max="10000"
                class="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-primary/20 text-xs font-semibold"
                required
              />
              <button 
                type="submit" 
                class="glow-btn bg-success hover:bg-green-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap"
              >
                + Load
              </button>
            </div>
          </form>

          <div class="space-y-2 pt-2 border-t border-slate-100">
            <label class="block text-[9px] font-bold text-slate-400 uppercase tracking-wide">Wallet Ledger Logs</label>
            <div id="wallet-recent-transactions" class="space-y-2 max-h-48 overflow-y-auto pr-1 scrollbar text-[10px] font-semibold text-slate-600">
              <p class="text-slate-400 text-center py-2">Loading logs...</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Update Forms -->
      <div class="md:col-span-2 space-y-8">
        
        <!-- Info Update -->
        <div class="glass-panel rounded-2xl p-6 shadow-md border border-white space-y-6">
          <h3 class="text-lg font-serif font-bold text-slate-800 pb-3 border-b border-slate-100">Update Profile Particulars</h3>
          
          <form id="profile-info-form" class="space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Full Name</label>
                <input 
                  type="text" 
                  id="profile-name" 
                  value="${state.user.name}"
                  class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition text-sm font-semibold"
                  required
                />
              </div>
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Mobile Number</label>
                <input 
                  type="text" 
                  id="profile-mobile" 
                  value="${state.user.mobile || ''}"
                  maxlength="10"
                  class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition text-sm font-semibold"
                  required
                />
              </div>
            </div>
            <button 
              type="submit" 
              class="glow-btn bg-primary hover:bg-primary-light text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-md transition"
            >
              Save Profile
            </button>
          </form>
        </div>

        <!-- Password Change -->
        <div class="glass-panel rounded-2xl p-6 shadow-md border border-white space-y-6">
          <h3 class="text-lg font-serif font-bold text-slate-800 pb-3 border-b border-slate-100">Change Password</h3>
          
          <form id="profile-pass-form" class="space-y-4">
            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Current Password</label>
              <input 
                type="password" 
                id="old-pass"
                class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"
                required
              />
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">New Password</label>
                <input 
                  type="password" 
                  id="new-pass"
                  class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"
                  required
                />
              </div>
              <div>
                <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Confirm New Password</label>
                <input 
                  type="password" 
                  id="confirm-new-pass"
                  class="w-full px-4 py-2.5 rounded-xl border border-slate-200 transition"
                  required
                />
              </div>
            </div>
            <button 
              type="submit" 
              class="glow-btn bg-accent hover:bg-accent-light text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-md transition"
            >
              Update Password
            </button>
          </form>
        </div>

      </div>
    </div>
  `;

  // Fetch and render eWallet balances
  (async () => {
    try {
      const res = await apiRequest('/api/payments/ewallet/balance');
      
      const balElem = document.getElementById('wallet-profile-balance');
      if (balElem) balElem.innerText = `₹${res.balance.toFixed(2)}`;

      const txElem = document.getElementById('wallet-recent-transactions');
      if (txElem) {
        if (res.transactions.length === 0) {
          txElem.innerHTML = `<p class="text-slate-400 text-center py-6 text-[10px]">No wallet ledger entries.</p>`;
        } else {
          txElem.innerHTML = res.transactions.map(t => {
            const isPos = t.amount >= 0;
            const colorClass = isPos ? 'text-success' : 'text-error';
            const sign = isPos ? '+' : '';
            const dtStr = new Date(t.created_at).toLocaleDateString(undefined, {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'});
            return `
              <div class="flex justify-between items-start pb-2 border-b border-slate-50 last:border-0">
                <div class="pr-2 leading-snug">
                  <div class="text-slate-700 text-[10px] font-bold">${t.description}</div>
                  <div class="text-[8px] text-slate-400 mt-0.5">${dtStr} | ${t.type}</div>
                </div>
                <span class="${colorClass} font-mono font-bold text-[10px] whitespace-nowrap">${sign}₹${Math.abs(t.amount).toFixed(2)}</span>
              </div>
            `;
          }).join('');
        }
      }
    } catch (err) {
      console.error("Failed to load eWallet stats:", err);
    }
  })();

  // Top Up Action
  document.getElementById('wallet-topup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const amountElem = document.getElementById('wallet-topup-amount');
    const amountVal = parseFloat(amountElem.value);

    if (isNaN(amountVal) || amountVal <= 0) {
      showAlert('Please input a valid top-up amount.');
      return;
    }

    try {
      await apiRequest('/api/payments/ewallet/topup', {
        method: 'POST',
        body: JSON.stringify({ amount: amountVal })
      });
      showAlert(`Successfully loaded ₹${amountVal.toFixed(2)} into your eWallet!`, 'success');
      amountElem.value = '';
      renderProfile();
    } catch (err) {
      showAlert(err.message);
    }
  });

  // Info submit
  document.getElementById('profile-info-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('profile-name').value.trim();
    const mobile = document.getElementById('profile-mobile').value.trim();

    if (!/^[6-9]\d{9}$/.test(mobile)) {
      showAlert('Mobile number must be exactly 10 digits starting with 6-9.');
      return;
    }

    try {
      const res = await apiRequest('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ full_name: name, mobile: mobile })
      });
      setCurrentUser(res);
      showAlert('Profile particulars saved successfully.', 'success');
      renderProfile();
    } catch (err) {
      showAlert(err.message);
    }
  });

  // Pass submit
  document.getElementById('profile-pass-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const oldP = document.getElementById('old-pass').value;
    const newP = document.getElementById('new-pass').value;
    const confirmP = document.getElementById('confirm-new-pass').value;

    if (newP !== confirmP) {
      showAlert('New passwords do not match.');
      return;
    }

    try {
      await apiRequest('/api/auth/change-password', {
        method: 'PUT',
        body: JSON.stringify({ old_password: oldP, new_password: newP })
      });
      showAlert('Password updated successfully.', 'success');
      e.target.reset();
    } catch (err) {
      showAlert(err.message);
    }
  });

  renderFooter();
}

// ==========================================
// AUTH: Sign In & Register Views
// ==========================================
function renderLogin() {
  const container = document.getElementById('app');
  container.innerHTML = `
    <div class="max-w-md mx-auto px-6 py-16">
      <div class="glass-panel rounded-2xl p-8 shadow-xl border border-white space-y-6">
        <div class="text-center space-y-2">
          <h2 class="text-2xl font-serif font-bold text-primary">Welcome Back</h2>
          <p class="text-xs text-slate-400 font-semibold uppercase tracking-wider">Access Premium Rail Nova Reservation System</p>
        </div>

        <form id="login-form" class="space-y-4">
          <div>
            <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Email Address</label>
            <input 
              type="email" 
              id="login-email" 
              placeholder="e.g. user@domain.com"
              class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-primary/20 transition text-sm font-semibold"
              required
            />
          </div>

          <div>
            <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Password</label>
            <input 
              type="password" 
              id="login-password" 
              placeholder="••••••••"
              class="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-primary/20 transition"
              required
            />
          </div>

          <button 
            type="submit" 
            class="glow-btn w-full bg-primary hover:bg-primary-light text-white py-3.5 rounded-xl font-bold text-sm shadow-md transition uppercase tracking-wider"
          >
            Sign In
          </button>
        </form>

        <div class="text-center text-xs text-slate-400 font-semibold border-t border-slate-100 pt-4">
          Don't have an account? 
          <button onclick="navigateTo('register')" class="text-primary hover:underline font-bold">Register Now</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    try {
      const res = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });

      state.token = res.access_token;
      localStorage.setItem('token', res.access_token);
      
      const success = await checkAuth();
      if (success) {
        showAlert('Successfully authenticated.', 'success');
        navigateTo('home');
      }
    } catch (err) {
      showAlert(err.message);
    }
  });

  renderFooter();
}

function renderRegister() {
  const container = document.getElementById('app');
  container.innerHTML = `
    <div class="max-w-2xl mx-auto px-6 py-12">
      <div class="glass-panel rounded-2xl p-8 shadow-xl border border-white space-y-6">
        <div class="text-center space-y-2">
          <h2 class="text-2xl font-serif font-bold text-primary">Create Premium Booker Account</h2>
          <p class="text-xs text-slate-400 font-semibold uppercase tracking-wider">Validate Aadhaar / PAN for rapid ticketing</p>
        </div>

        <form id="register-form" class="space-y-6">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Full Name (As in Aadhaar)</label>
              <input type="text" id="reg-name" placeholder="e.g. Rahul Sharma" class="w-full px-4 py-3 rounded-xl border border-slate-200 transition" required/>
            </div>
            
            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Email Address</label>
              <input type="email" id="reg-email" placeholder="e.g. rahul@domain.com" class="w-full px-4 py-3 rounded-xl border border-slate-200 transition" required/>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Aadhaar Number (12 Digits - Optional)</label>
              <input type="text" id="reg-aadhaar" placeholder="e.g. 123456789012" maxlength="12" class="w-full px-4 py-3 rounded-xl border border-slate-200 transition"/>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">PAN Card ID (10 Digits - Optional)</label>
              <input type="text" id="reg-pan" placeholder="e.g. ABCDE1234F" maxlength="10" class="w-full px-4 py-3 rounded-xl border border-slate-200 transition"/>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Mobile Number (10 Digits)</label>
              <input type="text" id="reg-mobile" placeholder="e.g. 9876543210" maxlength="10" class="w-full px-4 py-3 rounded-xl border border-slate-200 transition" required/>
            </div>

            <div>
              <label class="block text-xs font-bold text-slate-500 uppercase mb-2">Secure Password</label>
              <input type="password" id="reg-password" placeholder="••••••••" class="w-full px-4 py-3 rounded-xl border border-slate-200 transition" required/>
            </div>
          </div>

          <button 
            type="submit" 
            class="glow-btn w-full bg-primary hover:bg-primary-light text-white py-4 rounded-xl font-bold text-md shadow-lg transition uppercase tracking-wider"
          >
            Create Booker Account
          </button>
        </form>

        <div class="text-center text-xs text-slate-400 font-semibold border-t border-slate-100 pt-4">
          Already have an account? 
          <button onclick="navigateTo('login')" class="text-primary hover:underline font-bold">Sign In</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const aadhaar = document.getElementById('reg-aadhaar').value.trim();
    const pan = document.getElementById('reg-pan').value.trim().toUpperCase();
    const mobile = document.getElementById('reg-mobile').value.trim();
    const password = document.getElementById('reg-password').value;

    // Regex Checks (only validate if provided since they are optional)
    if (aadhaar && !/^\d{12}$/.test(aadhaar)) {
      showAlert('Aadhaar number must be exactly 12 numeric digits.');
      return;
    }
    if (pan && !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan)) {
      showAlert('PAN format is invalid (e.g. ABCDE1234F).');
      return;
    }
    if (!/^[6-9]\d{9}$/.test(mobile)) {
      showAlert('Mobile number must be exactly 10 digits starting with 6-9.');
      return;
    }

    try {
      const payload = {
        full_name: name,
        email: email,
        password: password,
        mobile: mobile,
        id_type: aadhaar ? 'Aadhaar' : (pan ? 'PAN' : null),
        id_number: aadhaar || pan || null
      };

      await apiRequest('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showAlert('Account registered successfully! You can sign in now.', 'success');
      navigateTo('login');
    } catch (err) {
      showAlert(err.message);
    }
  });

  renderFooter();
}

// ==========================================
// INITIALIZATION & HEARBEAT
// ==========================================
let heartbeatWs;
function startHeartbeat() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws/heartbeat`;
  
  heartbeatWs = new WebSocket(wsUrl);
  
  heartbeatWs.onclose = () => {
    // Reconnect after 3 seconds if disconnected
    setTimeout(startHeartbeat, 3000);
  };
}

document.addEventListener('DOMContentLoaded', async () => {
  // Start heartbeat to auto-shutdown server when browser exits
  startHeartbeat();

  // 1. Initial Auth Check
  await checkAuth();

  // 2. Setup Base Container Navigation Links
  const header = document.createElement('header');
  header.id = 'navbar-container';
  header.className = 'print:hidden';
  document.body.prepend(header);
  
  // 3. Mount current hash route or default Home
  renderNavbar();
  handleHashChange();
});

// ==========================================
// PRINT & PDF DOWNLOAD ENGINES
// ==========================================
window.downloadTicketPDF = async function(pnr) {
  try {
    const booking = await apiRequest(`/api/bookings/${pnr}`);
    if (!booking) throw new Error('Booking record not found.');

    const printArea = document.getElementById('print-area');
    if (!printArea) return;

    // Build passenger table rows
    const passengersHtml = booking.passengers.map((p, i) => `
      <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
        <td style="padding: 12px 10px; font-weight: bold; text-align: left; color: #475569;">${i + 1}</td>
        <td style="padding: 12px 10px; font-weight: 700; text-align: left; text-transform: uppercase; color: #0f172a;">${p.name}</td>
        <td style="padding: 12px 10px; font-weight: 600; text-align: center; color: #334155;">${p.age} / ${p.gender}</td>
        <td style="padding: 12px 10px; font-weight: 600; text-align: center; color: #1a3c8f;">${p.berth_pref || 'No Preference'}</td>
        <td style="padding: 12px 10px; font-weight: 700; text-align: center; color: #16a34a; font-family: monospace;">${p.status}</td>
        <td style="padding: 12px 10px; font-weight: 800; text-align: center; font-family: monospace; color: #0f172a; background-color: #f8fafc;">${p.coach_number && p.seat_number ? `${p.coach_number} / Berth ${p.seat_number} ${p.berth_type ? `(${p.berth_type})` : ''}` : 'CNF (AUTO-ALLOCATED)'}</td>
      </tr>
    `).join('');

    printArea.innerHTML = `
      <div style="max-width: 800px; margin: 0 auto; padding: 40px; font-family: 'Inter', sans-serif; color: #0f172a; background-color: #ffffff; border: 2px solid #1a3c8f; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);">
        
        <!-- Header Branding -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 4px double #1a3c8f; padding-bottom: 20px; margin-bottom: 24px;">
          <div style="display: flex; align-items: center; gap: 14px;">
            <span style="font-size: 40px; line-height: 1;">🚂</span>
            <div>
              <h1 style="font-size: 22px; font-weight: 900; margin: 0; color: #1a3c8f; font-family: 'Merriweather', serif;">Rail Nova</h1>
              <p style="font-size: 9px; font-weight: 700; margin: 3px 0 0 0; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">Ministry of Railways, Govt. of India</p>
            </div>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 11px; font-weight: 800; background-color: #1a3c8f; color: #ffffff; padding: 5px 10px; border-radius: 6px; text-transform: uppercase; letter-spacing: 0.5px;">Electronic Reservation Slip (ERS)</span>
            <p style="font-size: 9px; font-weight: 600; color: #64748b; margin: 6px 0 0 0;">Booked on: ${new Date(booking.created_at).toLocaleString()}</p>
          </div>
        </div>

        <!-- PNR and Train Meta -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin-bottom: 24px;">
          <div>
            <span style="font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 1px;">PNR Number</span>
            <div style="font-size: 22px; font-weight: 900; color: #1a3c8f; font-family: monospace; letter-spacing: 3px; margin-top: 3px;">${booking.pnr}</div>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 10px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 1px;">Overall Ticket Status</span>
            <div style="font-size: 18px; font-weight: 900; color: #16a34a; margin-top: 3px; text-transform: uppercase; letter-spacing: 0.5px;">${booking.status}</div>
          </div>
        </div>

        <!-- Journey Summary Grid -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin-bottom: 24px; font-size: 12px; line-height: 1.5;">
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Train Number & Name</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">#${booking.train_number} - ${booking.train_name}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">From Station</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">${booking.from_station}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">To Station</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">${booking.to_station}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Date of Journey</span>
            <div style="font-weight: 800; color: #f97316; margin-top: 4px; font-size: 13px;">${booking.journey_date}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Coach Class</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">${booking.coach_class}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Quota Type</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">${booking.is_tatkal ? 'TATKAL SURCHARGE' : 'GENERAL'}</div>
          </div>
        </div>

        <!-- Passenger Table -->
        <h3 style="font-size: 14px; font-weight: 800; color: #1a3c8f; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin: 0 0 12px 0; text-transform: uppercase; font-family: 'Merriweather', serif; letter-spacing: 0.5px;">Passenger & Berth Information</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 28px;">
          <thead>
            <tr style="background-color: #f8fafc; border-bottom: 2px solid #cbd5e1; font-size: 10px; font-weight: 800; text-transform: uppercase; color: #475569;">
              <th style="padding: 12px 10px; text-align: left; width: 45px;">S.No</th>
              <th style="padding: 12px 10px; text-align: left;">Passenger Name</th>
              <th style="padding: 12px 10px; text-align: center; width: 110px;">Age / Gender</th>
              <th style="padding: 12px 10px; text-align: center; width: 140px;">Berth Preference</th>
              <th style="padding: 12px 10px; text-align: center; width: 110px;">Booking Status</th>
              <th style="padding: 12px 10px; text-align: center; width: 150px; background-color: #f1f5f9;">Allocated Coach/Seat</th>
            </tr>
          </thead>
          <tbody>
            ${passengersHtml}
          </tbody>
        </table>

        <!-- Fare breakdown -->
        <h3 style="font-size: 14px; font-weight: 800; color: #1a3c8f; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin: 0 0 12px 0; text-transform: uppercase; font-family: 'Merriweather', serif; letter-spacing: 0.5px;">Fare Summary & Payment Settlement</h3>
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 12px; margin-bottom: 28px; padding: 15px 18px; background-color: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px;">
          <div>
            <p style="margin: 0; font-weight: 700; color: #334155; font-size: 13px;">Ticket Base Fare: <span style="color: #0f172a;">₹${booking.total_fare}</span></p>
            <p style="margin: 3px 0 0 0; font-size: 9px; font-weight: 600; color: #94a3b8; text-transform: uppercase;">Convenience & PG Charges: Included (₹0.00)</p>
          </div>
          <div style="text-align: right;">
            <p style="margin: 0; font-size: 14px; font-weight: 900; color: #1a3c8f;">Total Charged: ₹${booking.total_fare}</p>
            <p style="margin: 3px 0 0 0; font-size: 9px; font-weight: 600; color: #16a34a; text-transform: uppercase; font-family: monospace;">Simulated Transaction Verified (PAID)</p>
          </div>
        </div>

        <!-- Identity Verification Carrying Note -->
        <div style="background-color: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 15px; font-size: 11px; font-weight: 600; color: #92400e; display: flex; gap: 12px; align-items: start; margin-bottom: 28px; line-height: 1.45;">
          <span style="font-size: 18px; line-height: 1;">⚠️</span>
          <div>
            <strong style="text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; display: block; margin-bottom: 4px;">Important Note on ID Verification:</strong>
            At least one of the passengers booked on this Electronic Reservation Slip (ERS) must carry a valid original Identity Proof (Aadhaar Card, PAN Card, Voter Identity Card, Driving License, Passport, or Student Photo ID card) during train travel for inspection by the Ticket Examiner (TTE). Failure to produce a valid ID card may result in penal actions under section 138 of the Indian Railways Act.
          </div>
        </div>

        <!-- Footer -->
        <div style="border-top: 1px solid #e2e8f0; padding-top: 15px; text-align: center; font-size: 9px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px;">
          Thank you for choosing Rail Nova. Have a safe, comfortable & happy journey!
        </div>
      </div>
    `;

    // Wait a brief millisecond to let DOM inject and render fully, then open print dialog
    setTimeout(() => {
      window.print();
    }, 100);
  } catch (err) {
    showAlert(err.message);
  }
};

window.downloadCancellationPDF = async function(pnr) {
  try {
    const booking = await apiRequest(`/api/bookings/${pnr}`);
    if (!booking) throw new Error('Booking record not found.');

    const printArea = document.getElementById('print-area');
    if (!printArea) return;

    // Build passenger table rows showing CANCELLED status
    const passengersHtml = booking.passengers.map((p, i) => `
      <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
        <td style="padding: 12px 10px; font-weight: bold; text-align: left; color: #475569;">${i + 1}</td>
        <td style="padding: 12px 10px; font-weight: 700; text-align: left; text-transform: uppercase; color: #0f172a;">${p.name}</td>
        <td style="padding: 12px 10px; font-weight: 600; text-align: center; color: #334155;">${p.age} / ${p.gender}</td>
        <td style="padding: 12px 10px; font-weight: 600; text-align: center; color: #475569; font-family: monospace;">${p.coach_number && p.seat_number ? `${p.coach_number} / Berth ${p.seat_number} ${p.berth_type ? `(${p.berth_type})` : ''}` : 'Unassigned'}</td>
        <td style="padding: 12px 10px; font-weight: 800; text-align: center; color: #dc2626; text-transform: uppercase; letter-spacing: 0.5px;">CANCELLED</td>
      </tr>
    `).join('');

    const refundAmount = booking.total_fare; // Mock full refund
    const cancelCharge = 0.00; // Mock zero charges

    printArea.innerHTML = `
      <div style="max-width: 800px; margin: 0 auto; padding: 40px; font-family: 'Inter', sans-serif; color: #0f172a; background-color: #ffffff; border: 2px solid #dc2626; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);">
        
        <!-- Header Branding -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 4px double #dc2626; padding-bottom: 20px; margin-bottom: 24px;">
          <div style="display: flex; align-items: center; gap: 14px;">
            <span style="font-size: 40px; line-height: 1;">❌</span>
            <div>
              <h1 style="font-size: 22px; font-weight: 900; margin: 0; color: #dc2626; font-family: 'Merriweather', serif;">Rail Nova</h1>
              <p style="font-size: 9px; font-weight: 700; margin: 3px 0 0 0; color: #64748b; text-transform: uppercase; letter-spacing: 1.5px;">Ministry of Railways, Govt. of India</p>
            </div>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 11px; font-weight: 800; background-color: #dc2626; color: #ffffff; padding: 5px 10px; border-radius: 6px; text-transform: uppercase; letter-spacing: 0.5px;">Cancellation & Refund Slip</span>
            <p style="font-size: 9px; font-weight: 600; color: #64748b; margin: 6px 0 0 0;">Processed on: ${new Date().toLocaleString()}</p>
          </div>
        </div>

        <!-- PNR and Train Meta -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; background-color: #fef2f2; border: 1px solid #fca5a5; border-radius: 8px; padding: 18px; margin-bottom: 24px;">
          <div>
            <span style="font-size: 10px; font-weight: 800; color: #b91c1c; text-transform: uppercase; letter-spacing: 1px;">PNR Number</span>
            <div style="font-size: 22px; font-weight: 900; color: #b91c1c; font-family: monospace; letter-spacing: 3px; margin-top: 3px;">${booking.pnr}</div>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 10px; font-weight: 800; color: #b91c1c; text-transform: uppercase; letter-spacing: 1px;">Overall Ticket Status</span>
            <div style="font-size: 18px; font-weight: 900; color: #dc2626; margin-top: 3px; text-transform: uppercase; letter-spacing: 0.5px;">CANCELLED & REFUNDED</div>
          </div>
        </div>

        <!-- Journey Summary Grid -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; margin-bottom: 24px; font-size: 12px; line-height: 1.5;">
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Train Number & Name</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">#${booking.train_number} - ${booking.train_name}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">From Station</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">${booking.from_station}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">To Station</span>
            <div style="font-weight: 800; color: #0f172a; margin-top: 4px; font-size: 13px;">${booking.to_station}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Original Journey Date</span>
            <div style="font-weight: 800; color: #475569; margin-top: 4px; font-size: 13px;">${booking.journey_date}</div>
          </div>
          <div>
            <span style="font-weight: 700; color: #64748b; text-transform: uppercase; font-size: 9px; letter-spacing: 0.5px;">Coach Class</span>
            <div style="font-weight: 800; color: #475569; margin-top: 4px; font-size: 13px;">${booking.coach_class}</div>
          </div>
        </div>

        <!-- Passenger Table -->
        <h3 style="font-size: 14px; font-weight: 800; color: #dc2626; border-bottom: 2px solid #cbd5e1; padding-bottom: 8px; margin: 0 0 12px 0; text-transform: uppercase; font-family: 'Merriweather', serif; letter-spacing: 0.5px;">Cancelled Passengers</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 28px;">
          <thead>
            <tr style="background-color: #f8fafc; border-bottom: 2px solid #cbd5e1; font-size: 10px; font-weight: 800; text-transform: uppercase; color: #475569;">
              <th style="padding: 12px 10px; text-align: left; width: 45px;">S.No</th>
              <th style="padding: 12px 10px; text-align: left;">Passenger Name</th>
              <th style="padding: 12px 10px; text-align: center; width: 130px;">Age / Gender</th>
              <th style="padding: 12px 10px; text-align: center; width: 160px;">Original Coach/Seat</th>
              <th style="padding: 12px 10px; text-align: center; width: 140px;">Current Status</th>
            </tr>
          </thead>
          <tbody>
            ${passengersHtml}
          </tbody>
        </table>

        <!-- Refund calculations -->
        <h3 style="font-size: 14px; font-weight: 800; color: #dc2626; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin: 0 0 12px 0; text-transform: uppercase; font-family: 'Merriweather', serif; letter-spacing: 0.5px;">Refund Settlement Information</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 28px; font-size: 12px;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 0; font-weight: 600; color: #475569;">Original Total Ticket Fare Paid:</td>
            <td style="padding: 10px 0; text-align: right; font-weight: 700; color: #0f172a;">₹${booking.total_fare}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 0; font-weight: 600; color: #475569;">Cancellation Clerkage Charges Deducted:</td>
            <td style="padding: 10px 0; text-align: right; font-weight: 700; color: #dc2626;">- ₹${cancelCharge.toFixed(2)}</td>
          </tr>
          <tr style="border-bottom: 2px solid #dc2626; background-color: #fff5f5; font-size: 13px;">
            <td style="padding: 12px; font-weight: 800; color: #dc2626;">Total Refund Credited to Source Bank:</td>
            <td style="padding: 12px; text-align: right; font-weight: 900; color: #dc2626;">₹${refundAmount.toFixed(2)}</td>
          </tr>
        </table>

        <!-- Notice -->
        <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 15px; font-size: 11px; font-weight: 600; color: #1e3a8a; display: flex; gap: 12px; align-items: start; margin-bottom: 28px; line-height: 1.45;">
          <span style="font-size: 18px; line-height: 1;">ℹ️</span>
          <div>
            <strong style="text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; display: block; margin-bottom: 4px;">Refund Transaction Information:</strong>
            This cancellation has been logged by the Indian Railways centralized ticketing system. A net refund of <strong>₹${refundAmount.toFixed(2)}</strong> has been initiated and will reflect directly in the source bank account, credit/debit card, or VPA wallet used during booking verification within 3 to 5 business working days.
          </div>
        </div>

        <!-- Footer -->
        <div style="border-top: 1px solid #e2e8f0; padding-top: 15px; text-align: center; font-size: 9px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px;">
          Thank you for using Rail Nova. Have a safe & happy day!
        </div>
      </div>
    `;

    // Wait a brief millisecond to let DOM inject and render fully, then open print dialog
    setTimeout(() => {
      window.print();
    }, 100);
  } catch (err) {
    showAlert(err.message);
  }
};
