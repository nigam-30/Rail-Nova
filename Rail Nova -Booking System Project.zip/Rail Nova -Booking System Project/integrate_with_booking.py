"""
Integration snippet for Railway Ticket Booking System
Drop this into your existing project to use the real dataset
"""

import sqlite3
import os

DB_PATH = "indian_railways.db"  # path to the dataset DB

def get_connection():
    return sqlite3.connect(DB_PATH)

def search_trains(from_code: str, to_code: str):
    """Search trains between two station codes"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT train_number, train_name, from_station_name, to_station_name,
               departure, arrival, duration_h, duration_m, distance_km, train_type,
               has_1ac, has_2ac, has_3ac, has_sleeper, has_chair_car
        FROM trains
        WHERE from_station_code = ? AND to_station_code = ?
        ORDER BY departure
    """, (from_code.upper(), to_code.upper()))
    cols = [d[0] for d in cur.description]
    results = [dict(zip(cols, row)) for row in cur.fetchall()]
    conn.close()
    return results

def get_station(query: str):
    """Find station by name or code"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT station_code, station_name, zone, state
        FROM stations
        WHERE station_code = ? OR station_name LIKE ?
        LIMIT 10
    """, (query.upper(), f'%{query.upper()}%'))
    cols = [d[0] for d in cur.description]
    results = [dict(zip(cols, row)) for row in cur.fetchall()]
    conn.close()
    return results

def get_trains_from_station(station_code: str):
    """All trains departing from a station"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT train_number, train_name, to_station_name, departure, train_type, distance_km
        FROM trains WHERE from_station_code = ?
        ORDER BY departure
    """, (station_code.upper(),))
    cols = [d[0] for d in cur.description]
    results = [dict(zip(cols, row)) for row in cur.fetchall()]
    conn.close()
    return results

# --- DEMO ---
if __name__ == "__main__":
    # Find station code
    print("=== Station Search: MUMBAI ===")
    for s in get_station("MUMBAI")[:5]:
        print(s)

    # Search trains
    print("\n=== Trains: CSTM -> NDLS ===")
    for t in search_trains("CSTM", "NDLS"):
        print(t)

    # Trains from a station
    print("\n=== All trains from BCT (Mumbai Central) ===")
    for t in get_trains_from_station("BCT")[:5]:
        print(t)
